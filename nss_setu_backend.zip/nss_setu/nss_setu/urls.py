"""
NSS SETU - Main URL Configuration
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

# ─── Swagger / ReDoc API Docs ─────────────────────────────────────────────────
schema_view = get_schema_view(
    openapi.Info(
        title="NSS SETU API",
        default_version='v1',
        description="""
        NSS SETU Backend API
        
        A platform connecting NSS Volunteers, Programme Officers, NGOs, Hospitals and Villages.
        
        ## Authentication
        Use JWT Bearer tokens. Get your token via `/api/v1/auth/login/`
        """,
        contact=openapi.Contact(email="admin@nsssetu.in"),
        license=openapi.License(name="MIT License"),
    ),
    public=True,
    permission_classes=[permissions.AllowAny],
)

urlpatterns = [
    # Admin Panel
    path('admin/', admin.site.urls),

    # API v1
    path('api/v1/auth/',      include('apps.accounts.urls')),
    path('api/v1/events/',    include('apps.events.urls')),
    path('api/v1/attendance/',include('apps.attendance.urls')),
    path('api/v1/certificates/', include('apps.certificates.urls')),
    path('api/v1/community/', include('apps.community.urls')),
    path('api/v1/dashboard/', include('apps.dashboard.urls')),

    # API Docs
    path('docs/',    schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/',   schema_view.with_ui('redoc',   cache_timeout=0), name='schema-redoc'),
    path('swagger.json', schema_view.without_ui(cache_timeout=0),     name='schema-json'),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# Custom admin site branding
admin.site.site_header  = "NSS SETU Administration"
admin.site.site_title   = "NSS SETU Admin"
admin.site.index_title  = "Welcome to NSS SETU Admin Panel"
