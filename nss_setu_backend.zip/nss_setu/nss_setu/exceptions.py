"""
NSS SETU - Custom Exception Handler
Returns consistent JSON error responses across all endpoints
"""

from rest_framework.views import exception_handler
from rest_framework.response import Response
from rest_framework import status


def custom_exception_handler(exc, context):
    """
    Wraps DRF's default handler to produce a uniform error envelope:

    {
        "success": false,
        "error": {
            "code": "validation_error",
            "message": "...",
            "details": { ... }   // only for validation errors
        }
    }
    """
    response = exception_handler(exc, context)

    if response is not None:
        error_payload = {
            "success": False,
            "error": {}
        }

        # Determine a human-readable code
        status_code = response.status_code
        if status_code == 400:
            code = "validation_error"
        elif status_code == 401:
            code = "authentication_required"
        elif status_code == 403:
            code = "permission_denied"
        elif status_code == 404:
            code = "not_found"
        elif status_code == 405:
            code = "method_not_allowed"
        elif status_code == 429:
            code = "too_many_requests"
        else:
            code = "server_error"

        data = response.data

        # Flatten single-key detail responses
        if isinstance(data, dict) and list(data.keys()) == ['detail']:
            message = str(data['detail'])
            error_payload["error"] = {"code": code, "message": message}
        elif isinstance(data, dict):
            # Validation errors — keep details
            first_msg = ""
            for field, msgs in data.items():
                if isinstance(msgs, list) and msgs:
                    first_msg = f"{field}: {msgs[0]}"
                    break
                elif isinstance(msgs, str):
                    first_msg = msgs
                    break
            error_payload["error"] = {
                "code":    code,
                "message": first_msg or "Validation failed.",
                "details": data,
            }
        else:
            error_payload["error"] = {"code": code, "message": str(data)}

        response.data = error_payload

    return response
