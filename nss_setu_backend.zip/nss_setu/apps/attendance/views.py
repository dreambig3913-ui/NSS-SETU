"""NSS SETU - Attendance Views"""

from django.contrib.auth import get_user_model
from django.db.models import Sum
from django.conf import settings
from django.utils import timezone

from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import AttendanceSession, AttendanceRecord, ServiceHours
from .serializers import (
    AttendanceSessionSerializer, AttendanceSessionCreateSerializer,
    QRScanSerializer, ManualAttendanceSerializer,
    AttendanceRecordSerializer, ServiceHoursSerializer, HoursSummarySerializer,
)
from apps.accounts.permissions import IsProgrammeOfficer, IsVolunteer

User = get_user_model()
REQUIRED_HOURS = getattr(settings, 'NSS_REQUIRED_HOURS', 120)


# ─── Attendance Sessions ──────────────────────────────────────────────────────

class AttendanceSessionViewSet(viewsets.ModelViewSet):
    """
    POST   /api/v1/attendance/sessions/          → Create session (admin)
    GET    /api/v1/attendance/sessions/          → List sessions (admin)
    GET    /api/v1/attendance/sessions/<id>/     → Session detail
    PATCH  /api/v1/attendance/sessions/<id>/close/ → Close session
    GET    /api/v1/attendance/sessions/<id>/records/ → All records
    POST   /api/v1/attendance/sessions/<id>/manual/ → Manual mark
    """
    queryset = AttendanceSession.objects.select_related('event', 'created_by').all()

    def get_serializer_class(self):
        if self.action == 'create':
            return AttendanceSessionCreateSerializer
        return AttendanceSessionSerializer

    def get_permissions(self):
        if self.action in ['records', 'manual', 'close_session']:
            return [IsProgrammeOfficer()]
        if self.action == 'scan':
            return [IsVolunteer()]
        return [IsProgrammeOfficer()]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=['post'], url_path='close')
    def close_session(self, request, pk=None):
        """Close an attendance session"""
        session = self.get_object()
        session.status    = AttendanceSession.SessionStatus.CLOSED
        session.closes_at = timezone.now()
        session.save()
        return Response({'message': 'Session closed successfully.'})

    @action(detail=True, methods=['get'])
    def records(self, request, pk=None):
        """List all attendance records for a session"""
        session    = self.get_object()
        records    = session.records.select_related('volunteer').all()
        serializer = AttendanceRecordSerializer(records, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def manual(self, request, pk=None):
        """Manually mark attendance for a volunteer"""
        session    = self.get_object()
        serializer = ManualAttendanceSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            volunteer = User.objects.get(
                id=serializer.validated_data['volunteer_id'],
                role='volunteer'
            )
        except User.DoesNotExist:
            return Response({'error': 'Volunteer not found.'}, status=404)

        if AttendanceRecord.objects.filter(session=session, volunteer=volunteer).exists():
            return Response({'error': 'Attendance already marked.'}, status=400)

        record = AttendanceRecord.objects.create(
            session   = session,
            volunteer = volunteer,
            is_manual = True,
            marked_by = request.user,
            notes     = serializer.validated_data.get('notes', '')
        )
        return Response(
            AttendanceRecordSerializer(record).data,
            status=status.HTTP_201_CREATED
        )


# ─── QR Scan (Volunteer marks own attendance) ─────────────────────────────────

class QRScanView(generics.GenericAPIView):
    """
    POST /api/v1/attendance/scan/
    Volunteer scans QR code to mark attendance
    Body: { session_id, token }
    """
    serializer_class   = QRScanSerializer
    permission_classes = [IsVolunteer]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        session_id = serializer.validated_data['session_id']
        token      = serializer.validated_data['token']

        try:
            session = AttendanceSession.objects.select_related('event').get(
                id=session_id, session_token=token
            )
        except AttendanceSession.DoesNotExist:
            return Response({'error': 'Invalid QR code.'}, status=400)

        if session.status == AttendanceSession.SessionStatus.CLOSED:
            return Response({'error': 'This attendance session is closed.'}, status=400)

        if session.closes_at and timezone.now() > session.closes_at:
            session.status = AttendanceSession.SessionStatus.CLOSED
            session.save()
            return Response({'error': 'Attendance session has expired.'}, status=400)

        if AttendanceRecord.objects.filter(session=session, volunteer=request.user).exists():
            return Response({'error': 'Attendance already marked for this session.'}, status=400)

        record = AttendanceRecord.objects.create(
            session   = session,
            volunteer = request.user,
            is_manual = False,
        )
        return Response({
            'message': 'Attendance marked successfully!',
            'event':   session.event.title,
            'hours':   str(session.event.hours),
            'record':  AttendanceRecordSerializer(record).data,
        }, status=status.HTTP_201_CREATED)


# ─── Service Hours ────────────────────────────────────────────────────────────

class MyServiceHoursView(generics.ListAPIView):
    """
    GET /api/v1/attendance/my-hours/
    Volunteer's own service hours log
    """
    serializer_class   = ServiceHoursSerializer
    permission_classes = [IsVolunteer]

    def get_queryset(self):
        return ServiceHours.objects.filter(
            volunteer=self.request.user
        ).select_related('event').order_by('-earned_on')


class MyHoursSummaryView(generics.GenericAPIView):
    """
    GET /api/v1/attendance/my-hours/summary/
    Summary: total hours, percentage, certificate eligibility
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        total = ServiceHours.objects.filter(
            volunteer=request.user, verified=True
        ).aggregate(total=Sum('hours'))['total'] or 0

        total     = float(total)
        required  = REQUIRED_HOURS
        remaining = max(0, required - total)
        percentage = min(100.0, round((total / required) * 100, 2))

        events_attended = ServiceHours.objects.filter(
            volunteer=request.user, verified=True
        ).count()

        return Response({
            'total_hours':    total,
            'required_hours': required,
            'remaining_hours': remaining,
            'percentage':     percentage,
            'events_attended': events_attended,
            'eligible_for_certificate': total >= required,
        })


class VolunteerHoursView(generics.ListAPIView):
    """
    GET /api/v1/attendance/hours/?volunteer=<id>   (admin only)
    View hours for any volunteer
    """
    serializer_class   = ServiceHoursSerializer
    permission_classes = [IsProgrammeOfficer]

    def get_queryset(self):
        volunteer_id = self.request.query_params.get('volunteer')
        qs = ServiceHours.objects.select_related('volunteer', 'event').all()
        if volunteer_id:
            qs = qs.filter(volunteer_id=volunteer_id)
        return qs
