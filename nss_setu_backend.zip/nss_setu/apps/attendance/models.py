"""
NSS SETU - Attendance & Service Hours Models
QR-based attendance with automatic hours tracking
"""

import uuid
import json
import qrcode
from io import BytesIO

from django.db import models
from django.conf import settings
from django.core.files import File
from django.utils import timezone


class AttendanceSession(models.Model):
    """
    An attendance session is created by a Programme Officer for an event.
    Generates a unique QR code that volunteers scan to mark attendance.
    """

    class SessionStatus(models.TextChoices):
        OPEN   = 'open',   'Open'
        CLOSED = 'closed', 'Closed'

    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    event       = models.ForeignKey(
        'events.Event', on_delete=models.CASCADE, related_name='attendance_sessions'
    )
    created_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='attendance_sessions_created', limit_choices_to={'role': 'admin'}
    )
    session_token = models.UUIDField(default=uuid.uuid4, unique=True)  # Secret in QR
    qr_code       = models.ImageField(upload_to='qrcodes/', blank=True, null=True)
    status        = models.CharField(max_length=10, choices=SessionStatus.choices, default=SessionStatus.OPEN)
    opens_at      = models.DateTimeField(default=timezone.now)
    closes_at     = models.DateTimeField(null=True, blank=True)
    location_name = models.CharField(max_length=200, blank=True)
    created_at    = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Session for {self.event.title} ({self.status})"

    def generate_qr(self):
        """Generate and save QR code image encoding the session token"""
        payload = json.dumps({
            'session_id': str(self.id),
            'token':      str(self.session_token),
            'event':      str(self.event_id),
        })
        qr_img = qrcode.make(payload)
        buffer = BytesIO()
        qr_img.save(buffer, format='PNG')
        buffer.seek(0)
        filename = f"qr_{self.id}.png"
        self.qr_code.save(filename, File(buffer), save=False)

    def save(self, *args, **kwargs):
        is_new = self._state.adding
        super().save(*args, **kwargs)
        if is_new and not self.qr_code:
            self.generate_qr()
            super().save(update_fields=['qr_code'])

    class Meta:
        ordering     = ['-created_at']
        verbose_name = "Attendance Session"


class AttendanceRecord(models.Model):
    """Individual attendance record for a volunteer at an event session"""

    id        = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    session   = models.ForeignKey(
        AttendanceSession, on_delete=models.CASCADE, related_name='records'
    )
    volunteer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='attendance_records', limit_choices_to={'role': 'volunteer'}
    )
    marked_at = models.DateTimeField(auto_now_add=True)
    is_manual = models.BooleanField(default=False, help_text='Manually marked by officer')
    marked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='marked_attendances'
    )
    notes     = models.TextField(blank=True)

    class Meta:
        unique_together = ('session', 'volunteer')
        ordering        = ['-marked_at']
        verbose_name    = "Attendance Record"

    def __str__(self):
        return f"{self.volunteer.name} @ {self.session.event.title}"

    def save(self, *args, **kwargs):
        is_new = self._state.adding
        super().save(*args, **kwargs)
        if is_new:
            # Auto-create service hours entry
            ServiceHours.objects.get_or_create(
                volunteer=self.volunteer,
                event=self.session.event,
                defaults={'hours': self.session.event.hours, 'attendance': self}
            )


class ServiceHours(models.Model):
    """
    Tracks hours earned per volunteer per event.
    Auto-created when attendance is marked.
    """
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    volunteer  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='service_hours', limit_choices_to={'role': 'volunteer'}
    )
    event      = models.ForeignKey(
        'events.Event', on_delete=models.CASCADE, related_name='service_hours'
    )
    attendance = models.OneToOneField(
        AttendanceRecord, on_delete=models.CASCADE,
        null=True, blank=True, related_name='service_hours'
    )
    hours      = models.DecimalField(max_digits=6, decimal_places=2)
    earned_on  = models.DateTimeField(auto_now_add=True)
    verified   = models.BooleanField(default=True)
    note       = models.TextField(blank=True)

    class Meta:
        unique_together = ('volunteer', 'event')
        ordering        = ['-earned_on']
        verbose_name    = "Service Hours"
        verbose_name_plural = "Service Hours"

    def __str__(self):
        return f"{self.volunteer.name} — {self.hours}h @ {self.event.title}"
