"""NSS SETU - Attendance URLs"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register('sessions', views.AttendanceSessionViewSet, basename='attendance-session')

urlpatterns = [
    path('', include(router.urls)),
    path('scan/',                views.QRScanView.as_view(),          name='qr-scan'),
    path('my-hours/',            views.MyServiceHoursView.as_view(),  name='my-hours'),
    path('my-hours/summary/',    views.MyHoursSummaryView.as_view(),  name='my-hours-summary'),
    path('hours/',               views.VolunteerHoursView.as_view(),  name='all-hours'),
]
