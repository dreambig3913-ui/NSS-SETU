"""NSS SETU - Attendance Serializers"""

from rest_framework import serializers
from .models import AttendanceSession, AttendanceRecord, ServiceHours


class AttendanceSessionSerializer(serializers.ModelSerializer):
    event_title    = serializers.CharField(source='event.title', read_only=True)
    created_by_name = serializers.CharField(source='created_by.name', read_only=True)
    qr_code_url    = serializers.SerializerMethodField()
    record_count   = serializers.SerializerMethodField()

    class Meta:
        model  = AttendanceSession
        fields = [
            'id', 'event', 'event_title', 'created_by_name',
            'session_token', 'qr_code_url', 'status',
            'opens_at', 'closes_at', 'location_name',
            'record_count', 'created_at',
        ]
        read_only_fields = ['id', 'session_token', 'qr_code_url', 'created_at']

    def get_qr_code_url(self, obj):
        request = self.context.get('request')
        if obj.qr_code and request:
            return request.build_absolute_uri(obj.qr_code.url)
        return None

    def get_record_count(self, obj):
        return obj.records.count()


class AttendanceSessionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = AttendanceSession
        fields = ['event', 'opens_at', 'closes_at', 'location_name']


class QRScanSerializer(serializers.Serializer):
    """Payload sent when volunteer scans QR code"""
    session_id = serializers.UUIDField()
    token      = serializers.UUIDField()


class ManualAttendanceSerializer(serializers.Serializer):
    """Admin manually marks attendance for a volunteer"""
    volunteer_id = serializers.UUIDField()
    notes        = serializers.CharField(required=False, allow_blank=True)


class AttendanceRecordSerializer(serializers.ModelSerializer):
    volunteer_name  = serializers.CharField(source='volunteer.name', read_only=True)
    volunteer_email = serializers.CharField(source='volunteer.email', read_only=True)
    event_title     = serializers.CharField(source='session.event.title', read_only=True)
    marked_by_name  = serializers.CharField(source='marked_by.name', read_only=True)

    class Meta:
        model  = AttendanceRecord
        fields = [
            'id', 'session', 'volunteer', 'volunteer_name', 'volunteer_email',
            'event_title', 'marked_at', 'is_manual', 'marked_by_name', 'notes',
        ]
        read_only_fields = ['id', 'marked_at']


class ServiceHoursSerializer(serializers.ModelSerializer):
    volunteer_name = serializers.CharField(source='volunteer.name', read_only=True)
    event_title    = serializers.CharField(source='event.title', read_only=True)
    event_date     = serializers.DateTimeField(source='event.start_date', read_only=True)
    event_category = serializers.CharField(source='event.category', read_only=True)

    class Meta:
        model  = ServiceHours
        fields = [
            'id', 'volunteer', 'volunteer_name', 'event', 'event_title',
            'event_date', 'event_category', 'hours', 'earned_on', 'verified', 'note',
        ]
        read_only_fields = ['id', 'earned_on']


class HoursSummarySerializer(serializers.Serializer):
    """Summary of hours for a volunteer"""
    total_hours      = serializers.DecimalField(max_digits=8, decimal_places=2)
    required_hours   = serializers.IntegerField()
    remaining_hours  = serializers.DecimalField(max_digits=8, decimal_places=2)
    percentage       = serializers.FloatField()
    events_attended  = serializers.IntegerField()
    eligible_for_certificate = serializers.BooleanField()
