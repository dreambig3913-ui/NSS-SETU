"""NSS SETU - Attendance Admin"""
from django.contrib import admin
from .models import AttendanceSession, AttendanceRecord, ServiceHours


class AttendanceRecordInline(admin.TabularInline):
    model  = AttendanceRecord
    extra  = 0
    fields = ['volunteer', 'marked_at', 'is_manual', 'marked_by']
    readonly_fields = ['marked_at']


@admin.register(AttendanceSession)
class AttendanceSessionAdmin(admin.ModelAdmin):
    list_display  = ['event', 'status', 'opens_at', 'closes_at', 'location_name']
    list_filter   = ['status']
    search_fields = ['event__title']
    inlines       = [AttendanceRecordInline]


@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display  = ['volunteer', 'session', 'marked_at', 'is_manual']
    list_filter   = ['is_manual']
    search_fields = ['volunteer__name', 'session__event__title']


@admin.register(ServiceHours)
class ServiceHoursAdmin(admin.ModelAdmin):
    list_display  = ['volunteer', 'event', 'hours', 'earned_on', 'verified']
    list_filter   = ['verified']
    search_fields = ['volunteer__name', 'event__title']
