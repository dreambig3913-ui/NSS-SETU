"""NSS SETU - Dashboard URLs"""
from django.urls import path
from . import views

urlpatterns = [
    path('volunteer/',  views.VolunteerDashboardView.as_view(), name='volunteer-dashboard'),
    path('admin/',      views.AdminDashboardView.as_view(),     name='admin-dashboard'),
    path('unit-stats/', views.UnitStatsView.as_view(),          name='unit-stats'),
]
