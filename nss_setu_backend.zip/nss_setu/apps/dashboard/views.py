"""
NSS SETU - Dashboard API Views
Aggregated stats for volunteers and programme officers
"""

from django.contrib.auth import get_user_model
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import timedelta

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import IsProgrammeOfficer, IsVolunteer
from apps.events.models import Event, EventRegistration
from apps.attendance.models import ServiceHours, AttendanceRecord
from apps.certificates.models import Certificate
from apps.community.models import NGO, Hospital, Village, Project

User = get_user_model()


class VolunteerDashboardView(APIView):
    """
    GET /api/v1/dashboard/volunteer/
    Personal stats for the logged-in volunteer
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        # Hours
        hours_qs = ServiceHours.objects.filter(volunteer=user, verified=True)
        total_hours = hours_qs.aggregate(t=Sum('hours'))['t'] or 0
        required    = 120
        remaining   = max(0, required - float(total_hours))

        # Events
        registrations = EventRegistration.objects.filter(volunteer=user)
        events_joined     = registrations.count()
        events_attended   = registrations.filter(status='attended').count()
        events_registered = registrations.filter(status='registered').count()

        # Upcoming events
        upcoming = Event.objects.filter(
            registrations__volunteer=user,
            registrations__status='registered',
            start_date__gte=timezone.now(),
            status__in=['published', 'ongoing']
        ).order_by('start_date')[:3]

        upcoming_data = [
            {
                'id':         str(e.id),
                'title':      e.title,
                'start_date': e.start_date,
                'location':   e.location,
                'hours':      str(e.hours),
            }
            for e in upcoming
        ]

        # Certificate
        certificate = Certificate.objects.filter(
            volunteer=user, status='issued'
        ).first()

        # Recent hours log
        recent_hours = hours_qs.select_related('event').order_by('-earned_on')[:5]
        recent_hours_data = [
            {
                'event': sh.event.title,
                'hours': str(sh.hours),
                'date':  sh.earned_on,
            }
            for sh in recent_hours
        ]

        return Response({
            'volunteer': {
                'name':    user.name,
                'college': user.college,
                'unit':    user.nss_unit.name if user.nss_unit else None,
            },
            'hours': {
                'total':     float(total_hours),
                'required':  required,
                'remaining': remaining,
                'percentage': min(100, round((float(total_hours) / required) * 100, 1)),
            },
            'events': {
                'total_joined':    events_joined,
                'attended':        events_attended,
                'upcoming_count':  events_registered,
                'upcoming':        upcoming_data,
            },
            'certificate': {
                'issued':             certificate is not None,
                'certificate_number': certificate.certificate_number if certificate else None,
                'eligible':           float(total_hours) >= required,
            },
            'recent_hours': recent_hours_data,
        })


class AdminDashboardView(APIView):
    """
    GET /api/v1/dashboard/admin/
    Unit-level statistics for Programme Officers
    """
    permission_classes = [IsProgrammeOfficer]

    def get(self, request):
        unit = request.user.nss_unit

        # Filter by unit if assigned
        volunteer_qs = User.objects.filter(role='volunteer')
        event_qs     = Event.objects.all()
        hours_qs     = ServiceHours.objects.all()

        if unit:
            volunteer_qs = volunteer_qs.filter(nss_unit=unit)
            event_qs     = event_qs.filter(nss_unit=unit)
            hours_qs     = hours_qs.filter(volunteer__nss_unit=unit)

        # Core counts
        total_volunteers = volunteer_qs.count()
        total_events     = event_qs.count()
        completed_events = event_qs.filter(status='completed').count()
        total_hours      = hours_qs.aggregate(t=Sum('hours'))['t'] or 0

        # Certificates
        cert_qs = Certificate.objects.filter(status='issued')
        if unit:
            cert_qs = cert_qs.filter(nss_unit=unit)
        certs_issued = cert_qs.count()

        # Eligible but no cert
        eligible_no_cert = 0
        for vol in volunteer_qs:
            vol_hours = hours_qs.filter(volunteer=vol).aggregate(t=Sum('hours'))['t'] or 0
            if float(vol_hours) >= 120 and not cert_qs.filter(volunteer=vol).exists():
                eligible_no_cert += 1

        # Upcoming events (next 30 days)
        upcoming = event_qs.filter(
            start_date__gte=timezone.now(),
            start_date__lte=timezone.now() + timedelta(days=30),
            status__in=['published', 'ongoing']
        ).order_by('start_date')[:5]

        upcoming_data = [
            {
                'id':              str(e.id),
                'title':           e.title,
                'start_date':      e.start_date,
                'volunteer_count': e.volunteer_count,
                'hours':           str(e.hours),
            }
            for e in upcoming
        ]

        # Top volunteers by hours
        top_volunteers = []
        for vol in volunteer_qs.annotate(h=Sum('service_hours__hours')).order_by('-h')[:5]:
            top_volunteers.append({
                'name':  vol.name,
                'email': vol.email,
                'hours': float(vol.h or 0),
            })

        # Community counts
        community_counts = {}
        if unit:
            community_counts = {
                'ngos':      unit.ngos.filter(is_active=True).count(),
                'hospitals': unit.hospitals.filter(is_active=True).count(),
                'villages':  unit.villages.count(),
                'projects':  unit.projects.count(),
            }

        # Events by category
        by_category = list(
            event_qs.values('category').annotate(count=Count('id')).order_by('-count')
        )

        # Monthly hours trend (last 6 months)
        monthly_hours = []
        for i in range(5, -1, -1):
            month_start = (timezone.now() - timedelta(days=30 * i)).replace(
                day=1, hour=0, minute=0, second=0, microsecond=0
            )
            month_end = (month_start + timedelta(days=32)).replace(day=1)
            h = hours_qs.filter(
                earned_on__gte=month_start, earned_on__lt=month_end
            ).aggregate(t=Sum('hours'))['t'] or 0
            monthly_hours.append({
                'month': month_start.strftime('%b %Y'),
                'hours': float(h),
            })

        return Response({
            'unit': unit.name if unit else 'All Units',
            'summary': {
                'total_volunteers':   total_volunteers,
                'total_events':       total_events,
                'completed_events':   completed_events,
                'total_hours_served': float(total_hours),
                'certificates_issued': certs_issued,
                'eligible_no_cert':   eligible_no_cert,
            },
            'upcoming_events': upcoming_data,
            'top_volunteers':  top_volunteers,
            'community':       community_counts,
            'events_by_category': by_category,
            'monthly_hours_trend': monthly_hours,
        })


class UnitStatsView(APIView):
    """
    GET /api/v1/dashboard/unit-stats/
    High-level stats for an NSS unit (admin)
    """
    permission_classes = [IsProgrammeOfficer]

    def get(self, request):
        unit     = request.user.nss_unit
        base_qs  = User.objects.filter(role='volunteer')
        if unit:
            base_qs = base_qs.filter(nss_unit=unit)

        # Attendance rate for last 30 days
        recent_events = Event.objects.filter(
            start_date__gte=timezone.now() - timedelta(days=30)
        )
        if unit:
            recent_events = recent_events.filter(nss_unit=unit)

        attendance_rate = 0
        if recent_events.exists():
            total_regs     = EventRegistration.objects.filter(event__in=recent_events).count()
            attended       = EventRegistration.objects.filter(event__in=recent_events, status='attended').count()
            attendance_rate = round((attended / total_regs * 100), 1) if total_regs else 0

        return Response({
            'unit_name':       unit.name if unit else 'All',
            'active_volunteers': base_qs.filter(is_active=True).count(),
            'attendance_rate_30d': attendance_rate,
            'events_this_month': recent_events.count(),
        })
