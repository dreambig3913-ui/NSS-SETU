"""
NSS SETU - Events / Activities Models
"""

import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone


class Event(models.Model):
    """NSS Activity / Event"""

    class Status(models.TextChoices):
        DRAFT     = 'draft',     'Draft'
        PUBLISHED = 'published', 'Published'
        ONGOING   = 'ongoing',   'Ongoing'
        COMPLETED = 'completed', 'Completed'
        CANCELLED = 'cancelled', 'Cancelled'

    class Category(models.TextChoices):
        COMMUNITY_SERVICE = 'community_service', 'Community Service'
        HEALTH_CAMP       = 'health_camp',       'Health Camp'
        TREE_PLANTATION   = 'tree_plantation',   'Tree Plantation'
        BLOOD_DONATION    = 'blood_donation',    'Blood Donation'
        AWARENESS_DRIVE   = 'awareness_drive',   'Awareness Drive'
        SKILL_TRAINING    = 'skill_training',    'Skill Training'
        CULTURAL          = 'cultural',          'Cultural'
        OTHER             = 'other',             'Other'

    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title       = models.CharField(max_length=300)
    description = models.TextField()
    category    = models.CharField(max_length=50, choices=Category.choices, default=Category.OTHER)
    status      = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)

    # Organizer & Unit
    created_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='created_events', limit_choices_to={'role': 'admin'}
    )
    nss_unit    = models.ForeignKey(
        'accounts.NSSUnit', on_delete=models.SET_NULL, null=True,
        related_name='events'
    )

    # Scheduling
    start_date  = models.DateTimeField()
    end_date    = models.DateTimeField()
    location    = models.CharField(max_length=400)
    latitude    = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude   = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)

    # Hours & Capacity
    hours            = models.DecimalField(max_digits=5, decimal_places=2, help_text='Service hours for this event')
    max_volunteers   = models.PositiveIntegerField(null=True, blank=True)

    # Media
    image            = models.ImageField(upload_to='events/', null=True, blank=True)
    document         = models.FileField(upload_to='events/docs/', null=True, blank=True)

    # Timestamps
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} ({self.start_date.date()})"

    @property
    def is_registration_open(self):
        return self.status == self.Status.PUBLISHED and timezone.now() < self.start_date

    @property
    def volunteer_count(self):
        return self.registrations.filter(status='registered').count()

    class Meta:
        ordering = ['-start_date']
        verbose_name = "Event"


class EventRegistration(models.Model):
    """Volunteer registration for an event"""

    class RegistrationStatus(models.TextChoices):
        REGISTERED  = 'registered',  'Registered'
        ATTENDED    = 'attended',    'Attended'
        ABSENT      = 'absent',      'Absent'
        CANCELLED   = 'cancelled',   'Cancelled'

    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    event       = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='registrations')
    volunteer   = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='event_registrations', limit_choices_to={'role': 'volunteer'}
    )
    status      = models.CharField(
        max_length=20, choices=RegistrationStatus.choices,
        default=RegistrationStatus.REGISTERED
    )
    registered_at = models.DateTimeField(auto_now_add=True)
    notes         = models.TextField(blank=True)

    class Meta:
        unique_together = ('event', 'volunteer')
        ordering        = ['-registered_at']
        verbose_name    = "Event Registration"

    def __str__(self):
        return f"{self.volunteer.name} → {self.event.title}"
