"""NSS SETU - Events Views"""

from django.db import IntegrityError
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from .models import Event, EventRegistration
from .serializers import (
    EventListSerializer, EventDetailSerializer,
    EventCreateUpdateSerializer, EventRegistrationSerializer,
)
from apps.accounts.permissions import IsProgrammeOfficer, IsVolunteer


class EventViewSet(viewsets.ModelViewSet):
    """
    GET    /api/v1/events/           → List all published events
    POST   /api/v1/events/           → Create event (admin only)
    GET    /api/v1/events/<id>/      → Event detail
    PATCH  /api/v1/events/<id>/      → Update (admin only)
    DELETE /api/v1/events/<id>/      → Delete (admin only)
    POST   /api/v1/events/<id>/join/ → Volunteer joins event
    POST   /api/v1/events/<id>/leave/→ Volunteer leaves event
    GET    /api/v1/events/<id>/volunteers/ → List registered volunteers (admin)
    """

    queryset = Event.objects.select_related('created_by', 'nss_unit').all()
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['status', 'category', 'nss_unit']
    search_fields    = ['title', 'description', 'location']
    ordering_fields  = ['start_date', 'created_at', 'hours']

    def get_serializer_class(self):
        if self.action == 'list':
            return EventListSerializer
        if self.action in ['create', 'update', 'partial_update']:
            return EventCreateUpdateSerializer
        return EventDetailSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy', 'volunteers']:
            return [IsProgrammeOfficer()]
        return [IsAuthenticated()]

    def get_queryset(self):
        user = self.request.user
        qs   = super().get_queryset()
        # Volunteers only see published/ongoing/completed events
        if user.is_authenticated and user.role == 'volunteer':
            qs = qs.filter(status__in=['published', 'ongoing', 'completed'])
        return qs

    def perform_create(self, serializer):
        serializer.save(
            created_by=self.request.user,
            nss_unit=self.request.user.nss_unit or serializer.validated_data.get('nss_unit')
        )

    # ─── Custom Actions ───────────────────────────────────────────────────────

    @action(detail=True, methods=['post'], permission_classes=[IsVolunteer])
    def join(self, request, pk=None):
        """POST /api/v1/events/<id>/join/"""
        event = self.get_object()
        if not event.is_registration_open:
            return Response({'error': 'Registration is closed for this event.'}, status=400)
        if event.max_volunteers and event.volunteer_count >= event.max_volunteers:
            return Response({'error': 'Event is full.'}, status=400)
        try:
            reg = EventRegistration.objects.create(event=event, volunteer=request.user)
            return Response(
                EventRegistrationSerializer(reg).data,
                status=status.HTTP_201_CREATED
            )
        except IntegrityError:
            return Response({'error': 'Already registered for this event.'}, status=400)

    @action(detail=True, methods=['post'], permission_classes=[IsVolunteer])
    def leave(self, request, pk=None):
        """POST /api/v1/events/<id>/leave/"""
        event = self.get_object()
        deleted, _ = EventRegistration.objects.filter(
            event=event, volunteer=request.user, status='registered'
        ).delete()
        if deleted:
            return Response({'message': 'Successfully left the event.'})
        return Response({'error': 'Registration not found.'}, status=404)

    @action(detail=True, methods=['get'], permission_classes=[IsProgrammeOfficer])
    def volunteers(self, request, pk=None):
        """GET /api/v1/events/<id>/volunteers/ — list all registered volunteers"""
        event = self.get_object()
        regs  = event.registrations.select_related('volunteer').all()
        serializer = EventRegistrationSerializer(regs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='my-events')
    def my_events(self, request):
        """GET /api/v1/events/my-events/ — events I'm registered for"""
        regs = EventRegistration.objects.filter(
            volunteer=request.user
        ).select_related('event')
        events = [r.event for r in regs]
        serializer = EventListSerializer(events, many=True, context={'request': request})
        return Response(serializer.data)
