"""NSS SETU - Events Admin"""

from django.contrib import admin
from .models import Event, EventRegistration


class EventRegistrationInline(admin.TabularInline):
    model  = EventRegistration
    extra  = 0
    fields = ['volunteer', 'status', 'registered_at']
    readonly_fields = ['registered_at']


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display   = ['title', 'category', 'status', 'start_date', 'location', 'hours', 'volunteer_count']
    list_filter    = ['status', 'category', 'nss_unit']
    search_fields  = ['title', 'description', 'location']
    ordering       = ['-start_date']
    inlines        = [EventRegistrationInline]
    readonly_fields = ['created_at', 'updated_at']

    fieldsets = (
        ('Basic Info',   {'fields': ('title', 'description', 'category', 'status', 'image', 'document')}),
        ('Schedule',     {'fields': ('start_date', 'end_date', 'location', 'latitude', 'longitude')}),
        ('NSS Details',  {'fields': ('created_by', 'nss_unit', 'hours', 'max_volunteers')}),
        ('Timestamps',   {'fields': ('created_at', 'updated_at'), 'classes': ('collapse',)}),
    )


@admin.register(EventRegistration)
class EventRegistrationAdmin(admin.ModelAdmin):
    list_display  = ['volunteer', 'event', 'status', 'registered_at']
    list_filter   = ['status', 'event__nss_unit']
    search_fields = ['volunteer__name', 'volunteer__email', 'event__title']
