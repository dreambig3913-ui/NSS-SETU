"""NSS SETU - Events Serializers"""

from django.contrib.auth import get_user_model
from rest_framework import serializers

from .models import Event, EventRegistration

User = get_user_model()


class EventListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for event lists"""
    created_by_name  = serializers.CharField(source='created_by.name', read_only=True)
    nss_unit_name    = serializers.CharField(source='nss_unit.name', read_only=True)
    volunteer_count  = serializers.ReadOnlyField()
    is_registration_open = serializers.ReadOnlyField()
    image_url        = serializers.SerializerMethodField()

    class Meta:
        model  = Event
        fields = [
            'id', 'title', 'category', 'status', 'start_date', 'end_date',
            'location', 'hours', 'max_volunteers', 'volunteer_count',
            'is_registration_open', 'created_by_name', 'nss_unit_name', 'image_url',
        ]

    def get_image_url(self, obj):
        request = self.context.get('request')
        if obj.image and request:
            return request.build_absolute_uri(obj.image.url)
        return None


class EventDetailSerializer(serializers.ModelSerializer):
    """Full event details"""
    created_by_name      = serializers.CharField(source='created_by.name', read_only=True)
    nss_unit_name        = serializers.CharField(source='nss_unit.name', read_only=True)
    volunteer_count      = serializers.ReadOnlyField()
    is_registration_open = serializers.ReadOnlyField()
    is_registered        = serializers.SerializerMethodField()
    image_url            = serializers.SerializerMethodField()

    class Meta:
        model  = Event
        fields = [
            'id', 'title', 'description', 'category', 'status',
            'start_date', 'end_date', 'location', 'latitude', 'longitude',
            'hours', 'max_volunteers', 'volunteer_count', 'is_registration_open',
            'is_registered', 'created_by_name', 'nss_unit_name',
            'image_url', 'document', 'created_at', 'updated_at',
        ]

    def get_image_url(self, obj):
        request = self.context.get('request')
        if obj.image and request:
            return request.build_absolute_uri(obj.image.url)
        return None

    def get_is_registered(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return obj.registrations.filter(volunteer=request.user).exists()
        return False


class EventCreateUpdateSerializer(serializers.ModelSerializer):
    """Create / Update events (admin only)"""

    class Meta:
        model  = Event
        fields = [
            'title', 'description', 'category', 'status',
            'start_date', 'end_date', 'location', 'latitude', 'longitude',
            'hours', 'max_volunteers', 'nss_unit', 'image', 'document',
        ]

    def validate(self, data):
        if data.get('end_date') and data.get('start_date'):
            if data['end_date'] <= data['start_date']:
                raise serializers.ValidationError({'end_date': 'End date must be after start date.'})
        return data


class EventRegistrationSerializer(serializers.ModelSerializer):
    volunteer_name  = serializers.CharField(source='volunteer.name', read_only=True)
    volunteer_email = serializers.CharField(source='volunteer.email', read_only=True)
    event_title     = serializers.CharField(source='event.title', read_only=True)

    class Meta:
        model  = EventRegistration
        fields = [
            'id', 'event', 'volunteer', 'volunteer_name', 'volunteer_email',
            'event_title', 'status', 'registered_at', 'notes',
        ]
        read_only_fields = ['id', 'registered_at', 'volunteer']
