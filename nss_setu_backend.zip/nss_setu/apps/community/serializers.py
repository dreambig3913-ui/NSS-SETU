"""NSS SETU - Community Serializers"""

from rest_framework import serializers
from .models import NGO, Hospital, Village, Project


class NGOSerializer(serializers.ModelSerializer):
    added_by_name = serializers.CharField(source='added_by.name', read_only=True)

    class Meta:
        model  = NGO
        fields = [
            'id', 'name', 'description', 'registration_number', 'nss_unit',
            'address', 'city', 'state', 'pincode', 'latitude', 'longitude',
            'contact_name', 'contact_phone', 'contact_email', 'website',
            'focus_areas', 'is_active', 'added_by_name', 'created_at',
        ]
        read_only_fields = ['id', 'created_at', 'added_by_name']


class HospitalSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Hospital
        fields = [
            'id', 'name', 'type', 'nss_unit', 'address', 'city',
            'contact_phone', 'contact_email', 'latitude', 'longitude',
            'has_blood_bank', 'is_active', 'created_at',
        ]
        read_only_fields = ['id', 'created_at']


class VillageSerializer(serializers.ModelSerializer):
    nss_unit_name = serializers.CharField(source='nss_unit.name', read_only=True)

    class Meta:
        model  = Village
        fields = [
            'id', 'name', 'taluka', 'district', 'state', 'pincode',
            'population', 'latitude', 'longitude', 'nss_unit', 'nss_unit_name',
            'is_adopted', 'adoption_date', 'amenities_notes', 'created_at',
        ]
        read_only_fields = ['id', 'created_at']


class ProjectSerializer(serializers.ModelSerializer):
    nss_unit_name  = serializers.CharField(source='nss_unit.name', read_only=True)
    village_name   = serializers.CharField(source='village.name', read_only=True)
    ngo_name       = serializers.CharField(source='ngo_partner.name', read_only=True)
    volunteer_count = serializers.SerializerMethodField()

    class Meta:
        model  = Project
        fields = [
            'id', 'title', 'description', 'status', 'nss_unit', 'nss_unit_name',
            'village', 'village_name', 'ngo_partner', 'ngo_name',
            'start_date', 'end_date', 'budget', 'volunteer_count',
            'image', 'created_by', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'volunteer_count']

    def get_volunteer_count(self, obj):
        return obj.volunteers.count()
