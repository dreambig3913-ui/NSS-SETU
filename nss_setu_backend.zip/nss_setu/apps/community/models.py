"""
NSS SETU - Community Mapping Models
NGOs, Hospitals, Villages, Projects linked to NSS Units
"""

import uuid
from django.db import models
from django.conf import settings


class NGO(models.Model):
    """Registered NGO partner"""
    id           = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name         = models.CharField(max_length=300)
    description  = models.TextField(blank=True)
    registration_number = models.CharField(max_length=100, blank=True, unique=True)
    nss_unit     = models.ForeignKey(
        'accounts.NSSUnit', on_delete=models.SET_NULL, null=True,
        related_name='ngos'
    )
    address      = models.TextField(blank=True)
    city         = models.CharField(max_length=100, blank=True)
    state        = models.CharField(max_length=100, default='Maharashtra')
    pincode      = models.CharField(max_length=6, blank=True)
    latitude     = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude    = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    contact_name  = models.CharField(max_length=200, blank=True)
    contact_phone = models.CharField(max_length=15, blank=True)
    contact_email = models.EmailField(blank=True)
    website      = models.URLField(blank=True)
    focus_areas  = models.CharField(max_length=500, blank=True, help_text='Comma-separated')
    is_active    = models.BooleanField(default=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    added_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='added_ngos'
    )

    def __str__(self):
        return self.name

    class Meta:
        ordering     = ['name']
        verbose_name = "NGO"


class Hospital(models.Model):
    """Hospitals linked to NSS units for blood donation / health camps"""
    id           = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name         = models.CharField(max_length=300)
    type         = models.CharField(max_length=50, choices=[
        ('government', 'Government'), ('private', 'Private'),
        ('trust', 'Trust'), ('other', 'Other'),
    ], default='government')
    nss_unit     = models.ForeignKey(
        'accounts.NSSUnit', on_delete=models.SET_NULL, null=True,
        related_name='hospitals'
    )
    address      = models.TextField()
    city         = models.CharField(max_length=100)
    contact_phone = models.CharField(max_length=15, blank=True)
    contact_email = models.EmailField(blank=True)
    latitude     = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude    = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    has_blood_bank = models.BooleanField(default=False)
    is_active    = models.BooleanField(default=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    added_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='added_hospitals'
    )

    def __str__(self):
        return f"{self.name} ({self.type})"

    class Meta:
        ordering     = ['name']
        verbose_name = "Hospital"


class Village(models.Model):
    """Villages adopted/served by NSS units"""
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name       = models.CharField(max_length=200)
    taluka     = models.CharField(max_length=100, blank=True)
    district   = models.CharField(max_length=100)
    state      = models.CharField(max_length=100, default='Maharashtra')
    pincode    = models.CharField(max_length=6, blank=True)
    population = models.PositiveIntegerField(null=True, blank=True)
    latitude   = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude  = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    nss_unit   = models.ForeignKey(
        'accounts.NSSUnit', on_delete=models.SET_NULL, null=True,
        related_name='villages'
    )
    is_adopted      = models.BooleanField(default=False)
    adoption_date   = models.DateField(null=True, blank=True)
    amenities_notes = models.TextField(blank=True, help_text='Roads, water, electricity etc.')
    created_at      = models.DateTimeField(auto_now_add=True)
    added_by        = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='added_villages'
    )

    def __str__(self):
        return f"{self.name}, {self.district}"

    class Meta:
        ordering     = ['district', 'name']
        verbose_name = "Village"


class Project(models.Model):
    """Community development projects run by NSS units"""

    class Status(models.TextChoices):
        PLANNED   = 'planned',   'Planned'
        ACTIVE    = 'active',    'Active'
        COMPLETED = 'completed', 'Completed'
        ON_HOLD   = 'on_hold',   'On Hold'

    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title       = models.CharField(max_length=300)
    description = models.TextField()
    status      = models.CharField(max_length=20, choices=Status.choices, default=Status.PLANNED)
    nss_unit    = models.ForeignKey(
        'accounts.NSSUnit', on_delete=models.SET_NULL, null=True,
        related_name='projects'
    )
    village     = models.ForeignKey(Village, on_delete=models.SET_NULL, null=True, blank=True)
    ngo_partner = models.ForeignKey(NGO, on_delete=models.SET_NULL, null=True, blank=True)
    start_date  = models.DateField(null=True, blank=True)
    end_date    = models.DateField(null=True, blank=True)
    budget      = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    volunteers  = models.ManyToManyField(
        settings.AUTH_USER_MODEL, blank=True, related_name='projects',
        limit_choices_to={'role': 'volunteer'}
    )
    image       = models.ImageField(upload_to='projects/', null=True, blank=True)
    created_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='created_projects'
    )
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} ({self.status})"

    class Meta:
        ordering     = ['-created_at']
        verbose_name = "Project"
