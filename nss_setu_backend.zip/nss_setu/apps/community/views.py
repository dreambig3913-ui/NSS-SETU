"""NSS SETU - Community Views"""

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.accounts.permissions import IsProgrammeOfficer
from .models import NGO, Hospital, Village, Project
from .serializers import NGOSerializer, HospitalSerializer, VillageSerializer, ProjectSerializer


class BaseCommunityCRUD(viewsets.ModelViewSet):
    """Base ViewSet — read for all, write for admins"""

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsProgrammeOfficer()]
        return [IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(added_by=self.request.user)


class NGOViewSet(BaseCommunityCRUD):
    queryset       = NGO.objects.select_related('nss_unit').all()
    serializer_class = NGOSerializer
    filterset_fields = ['nss_unit', 'is_active', 'city']
    search_fields    = ['name', 'description', 'city', 'focus_areas']


class HospitalViewSet(BaseCommunityCRUD):
    queryset       = Hospital.objects.select_related('nss_unit').all()
    serializer_class = HospitalSerializer
    filterset_fields = ['nss_unit', 'type', 'has_blood_bank', 'is_active']
    search_fields    = ['name', 'city', 'address']


class VillageViewSet(BaseCommunityCRUD):
    queryset       = Village.objects.select_related('nss_unit').all()
    serializer_class = VillageSerializer
    filterset_fields = ['nss_unit', 'district', 'is_adopted']
    search_fields    = ['name', 'district', 'taluka']

    def perform_create(self, serializer):
        serializer.save(
            added_by=self.request.user,
            nss_unit=self.request.user.nss_unit
        )


class ProjectViewSet(viewsets.ModelViewSet):
    queryset       = Project.objects.select_related('nss_unit', 'village', 'ngo_partner').all()
    serializer_class = ProjectSerializer
    filterset_fields = ['status', 'nss_unit']
    search_fields    = ['title', 'description']

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsProgrammeOfficer()]
        return [IsAuthenticated()]

    def perform_create(self, serializer):
        serializer.save(
            created_by=self.request.user,
            nss_unit=self.request.user.nss_unit
        )
