"""NSS SETU - Community URLs"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register('ngos',      views.NGOViewSet,      basename='ngo')
router.register('hospitals', views.HospitalViewSet, basename='hospital')
router.register('villages',  views.VillageViewSet,  basename='village')
router.register('projects',  views.ProjectViewSet,  basename='project')

urlpatterns = [path('', include(router.urls))]
