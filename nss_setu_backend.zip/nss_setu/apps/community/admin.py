"""NSS SETU - Community Admin"""
from django.contrib import admin
from .models import NGO, Hospital, Village, Project


@admin.register(NGO)
class NGOAdmin(admin.ModelAdmin):
    list_display  = ['name', 'city', 'nss_unit', 'contact_phone', 'is_active']
    list_filter   = ['is_active', 'nss_unit', 'state']
    search_fields = ['name', 'registration_number', 'city']


@admin.register(Hospital)
class HospitalAdmin(admin.ModelAdmin):
    list_display  = ['name', 'type', 'city', 'nss_unit', 'has_blood_bank', 'is_active']
    list_filter   = ['type', 'has_blood_bank', 'is_active', 'nss_unit']
    search_fields = ['name', 'city']


@admin.register(Village)
class VillageAdmin(admin.ModelAdmin):
    list_display  = ['name', 'district', 'nss_unit', 'is_adopted', 'population']
    list_filter   = ['is_adopted', 'district', 'nss_unit']
    search_fields = ['name', 'district', 'taluka']


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display  = ['title', 'status', 'nss_unit', 'start_date', 'end_date']
    list_filter   = ['status', 'nss_unit']
    search_fields = ['title', 'description']
    filter_horizontal = ['volunteers']
