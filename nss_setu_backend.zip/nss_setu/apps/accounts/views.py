"""
NSS SETU - Accounts Views
"""

import uuid
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta

from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import NSSUnit, VolunteerProfile
from .serializers import (
    CustomTokenObtainPairSerializer,
    VolunteerRegisterSerializer,
    AdminRegisterSerializer,
    UserProfileSerializer,
    UserUpdateSerializer,
    ChangePasswordSerializer,
    PasswordResetRequestSerializer,
    PasswordResetConfirmSerializer,
    EmailVerifySerializer,
    NSSUnitSerializer,
)
from .permissions import IsProgrammeOfficer, IsOwnerOrAdmin

User = get_user_model()


# ─── Authentication Views ─────────────────────────────────────────────────────

class LoginView(TokenObtainPairView):
    """
    POST /api/v1/auth/login/
    Returns access + refresh JWT tokens with user info
    """
    serializer_class = CustomTokenObtainPairSerializer
    permission_classes = [AllowAny]


class VolunteerRegisterView(generics.CreateAPIView):
    """
    POST /api/v1/auth/register/volunteer/
    Register a new NSS Volunteer
    """
    serializer_class   = VolunteerRegisterSerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        tokens = RefreshToken.for_user(user)
        return Response({
            'message': 'Volunteer registered successfully. Please verify your email.',
            'user': {
                'id':    str(user.id),
                'name':  user.name,
                'email': user.email,
                'role':  user.role,
            },
            'tokens': {
                'access':  str(tokens.access_token),
                'refresh': str(tokens),
            }
        }, status=status.HTTP_201_CREATED)


class AdminRegisterView(generics.CreateAPIView):
    """
    POST /api/v1/auth/register/admin/
    Register a new Programme Officer
    """
    serializer_class   = AdminRegisterSerializer
    permission_classes = [AllowAny]   # Can restrict to superadmin in production

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        tokens = RefreshToken.for_user(user)
        return Response({
            'message': 'Programme Officer registered successfully.',
            'user': {
                'id':    str(user.id),
                'name':  user.name,
                'email': user.email,
                'role':  user.role,
            },
            'tokens': {
                'access':  str(tokens.access_token),
                'refresh': str(tokens),
            }
        }, status=status.HTTP_201_CREATED)


class LogoutView(generics.GenericAPIView):
    """
    POST /api/v1/auth/logout/
    Blacklist the refresh token
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data.get('refresh')
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({'message': 'Logged out successfully.'}, status=status.HTTP_200_OK)
        except Exception:
            return Response({'error': 'Invalid token.'}, status=status.HTTP_400_BAD_REQUEST)


# ─── Profile Views ────────────────────────────────────────────────────────────

class MyProfileView(generics.RetrieveUpdateAPIView):
    """
    GET  /api/v1/auth/me/       → get own profile
    PATCH /api/v1/auth/me/      → update own profile
    """
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method in ['PATCH', 'PUT']:
            return UserUpdateSerializer
        return UserProfileSerializer

    def get_object(self):
        return self.request.user

    def update(self, request, *args, **kwargs):
        kwargs['partial'] = True
        return super().update(request, *args, **kwargs)


class ChangePasswordView(generics.GenericAPIView):
    """POST /api/v1/auth/change-password/"""
    serializer_class   = ChangePasswordSerializer
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = request.user
        if not user.check_password(serializer.validated_data['old_password']):
            return Response({'error': 'Incorrect current password.'}, status=status.HTTP_400_BAD_REQUEST)
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        return Response({'message': 'Password changed successfully.'})


# ─── Email Verification ───────────────────────────────────────────────────────

class EmailVerifyView(generics.GenericAPIView):
    """POST /api/v1/auth/verify-email/"""
    serializer_class   = EmailVerifySerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.validated_data['token']
        try:
            user = User.objects.get(email_verify_token=token)
            user.is_email_verified  = True
            user.email_verify_token = ''
            user.save()
            return Response({'message': 'Email verified successfully.'})
        except User.DoesNotExist:
            return Response({'error': 'Invalid or expired token.'}, status=status.HTTP_400_BAD_REQUEST)


# ─── Password Reset ───────────────────────────────────────────────────────────

class PasswordResetRequestView(generics.GenericAPIView):
    """POST /api/v1/auth/password-reset/"""
    serializer_class   = PasswordResetRequestSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        try:
            user = User.objects.get(email=email)
            user.password_reset_token   = str(uuid.uuid4())
            user.password_reset_expires = timezone.now() + timedelta(hours=24)
            user.save()
            # TODO: send_password_reset_email(user)
            return Response({'message': 'Password reset email sent if account exists.'})
        except User.DoesNotExist:
            # Don't leak whether email exists
            return Response({'message': 'Password reset email sent if account exists.'})


class PasswordResetConfirmView(generics.GenericAPIView):
    """POST /api/v1/auth/password-reset/confirm/"""
    serializer_class   = PasswordResetConfirmSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.validated_data['token']
        try:
            user = User.objects.get(
                password_reset_token=token,
                password_reset_expires__gt=timezone.now()
            )
            user.set_password(serializer.validated_data['new_password'])
            user.password_reset_token   = ''
            user.password_reset_expires = None
            user.save()
            return Response({'message': 'Password reset successful.'})
        except User.DoesNotExist:
            return Response({'error': 'Invalid or expired token.'}, status=status.HTTP_400_BAD_REQUEST)


# ─── User Management (Admin) ──────────────────────────────────────────────────

class UserListView(generics.ListAPIView):
    """GET /api/v1/auth/users/  → Admin only: list all users"""
    serializer_class   = UserProfileSerializer
    permission_classes = [IsProgrammeOfficer]
    filterset_fields   = ['role', 'nss_unit', 'is_email_verified']
    search_fields      = ['name', 'email', 'college']
    ordering_fields    = ['name', 'date_joined']

    def get_queryset(self):
        user = self.request.user
        qs   = User.objects.select_related('nss_unit').all()
        if user.nss_unit:
            qs = qs.filter(nss_unit=user.nss_unit)
        return qs


class UserDetailView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/v1/auth/users/<id>/"""
    serializer_class   = UserProfileSerializer
    permission_classes = [IsAuthenticated, IsOwnerOrAdmin]
    queryset           = User.objects.select_related('nss_unit').all()
    lookup_field       = 'id'


# ─── NSS Unit Views ───────────────────────────────────────────────────────────

class NSSUnitViewSet(viewsets.ModelViewSet):
    """CRUD for NSS Units"""
    serializer_class   = NSSUnitSerializer
    queryset           = NSSUnit.objects.all()
    search_fields      = ['name', 'unit_number', 'college']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [IsProgrammeOfficer()]
