"""
NSS SETU - Custom Permissions
"""
from rest_framework.permissions import BasePermission


class IsVolunteer(BasePermission):
    """Only NSS Volunteers can access"""
    message = "Access restricted to NSS Volunteers."

    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.role == 'volunteer'
        )


class IsProgrammeOfficer(BasePermission):
    """Only Programme Officers / Admins can access"""
    message = "Access restricted to Programme Officers."

    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.role == 'admin'
        )


class IsOwnerOrAdmin(BasePermission):
    """Object owner or admin can access"""
    def has_object_permission(self, request, view, obj):
        if request.user.role == 'admin':
            return True
        # works for User objects and objects with a 'user' FK
        if hasattr(obj, 'user'):
            return obj.user == request.user
        return obj == request.user


class IsSameUnitOrAdmin(BasePermission):
    """Users in same NSS unit or admin"""
    def has_object_permission(self, request, view, obj):
        if request.user.role == 'admin':
            return True
        user_unit = getattr(request.user, 'nss_unit', None)
        obj_unit  = getattr(obj, 'nss_unit', None)
        return user_unit and obj_unit and user_unit == obj_unit
