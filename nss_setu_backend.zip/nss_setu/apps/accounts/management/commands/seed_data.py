"""
NSS SETU - Seed Management Command
Usage: python manage.py seed_data

Creates sample data for development/testing:
  - 1 NSS Unit
  - 1 Programme Officer
  - 5 Volunteers
  - 3 Events
  - Sample NGO, Hospital, Village, Project
"""

from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta, date


class Command(BaseCommand):
    help = 'Seed the database with sample data for development'

    def add_arguments(self, parser):
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Clear existing data before seeding',
        )

    def handle(self, *args, **options):
        from django.contrib.auth import get_user_model
        from apps.accounts.models import NSSUnit, VolunteerProfile, ProgrammeOfficerProfile
        from apps.events.models import Event, EventRegistration
        from apps.community.models import NGO, Hospital, Village, Project

        User = get_user_model()

        if options['clear']:
            self.stdout.write(self.style.WARNING('Clearing existing data...'))
            User.objects.filter(is_superuser=False).delete()
            NSSUnit.objects.all().delete()
            NGO.objects.all().delete()
            Hospital.objects.all().delete()
            Village.objects.all().delete()

        self.stdout.write('Creating NSS Unit...')
        unit, _ = NSSUnit.objects.get_or_create(
            unit_number='MH-NSS-001',
            defaults={
                'name':     'NSS Unit Alpha',
                'college':  'Pune Engineering College',
                'district': 'Pune',
                'state':    'Maharashtra',
            }
        )

        self.stdout.write('Creating Programme Officer...')
        po, created = User.objects.get_or_create(
            email='po@nsssetu.in',
            defaults={
                'name':              'Dr. Ramesh Sharma',
                'role':              'admin',
                'college':           'Pune Engineering College',
                'nss_unit':          unit,
                'is_staff':          True,
                'is_email_verified': True,
            }
        )
        if created:
            po.set_password('Admin@1234')
            po.save()
            ProgrammeOfficerProfile.objects.get_or_create(
                user=po,
                defaults={'designation': 'Programme Officer', 'department': 'Civil Engineering'}
            )

        self.stdout.write('Creating Volunteers...')
        volunteers = []
        volunteer_data = [
            ('Priya Mehta',    'priya@student.in',   '9876543210'),
            ('Arjun Patil',    'arjun@student.in',   '9876543211'),
            ('Sneha Kulkarni', 'sneha@student.in',   '9876543212'),
            ('Rahul Desai',    'rahul@student.in',   '9876543213'),
            ('Kavya Joshi',    'kavya@student.in',   '9876543214'),
        ]
        for name, email, phone in volunteer_data:
            vol, created = User.objects.get_or_create(
                email=email,
                defaults={
                    'name':              name,
                    'role':              'volunteer',
                    'phone':             phone,
                    'college':           'Pune Engineering College',
                    'nss_unit':          unit,
                    'is_email_verified': True,
                }
            )
            if created:
                vol.set_password('Volunteer@1234')
                vol.save()
                VolunteerProfile.objects.get_or_create(
                    user=vol,
                    defaults={'year_of_study': 2, 'department': 'Computer Engineering'}
                )
            volunteers.append(vol)

        self.stdout.write('Creating Events...')
        now = timezone.now()

        events_data = [
            {
                'title':       'Village Cleanliness Drive',
                'description': 'Clean-up campaign at Wagholi village',
                'category':    'community_service',
                'status':      'completed',
                'start_date':  now - timedelta(days=30),
                'end_date':    now - timedelta(days=30) + timedelta(hours=4),
                'location':    'Wagholi, Pune',
                'hours':       4,
            },
            {
                'title':       'Blood Donation Camp',
                'description': 'Annual blood donation camp at Sassoon Hospital',
                'category':    'blood_donation',
                'status':      'published',
                'start_date':  now + timedelta(days=7),
                'end_date':    now + timedelta(days=7) + timedelta(hours=6),
                'location':    'Sassoon General Hospital, Pune',
                'hours':       6,
            },
            {
                'title':       'Tree Plantation Drive',
                'description': '500 trees to be planted near Khadakwasla',
                'category':    'tree_plantation',
                'status':      'published',
                'start_date':  now + timedelta(days=14),
                'end_date':    now + timedelta(days=14) + timedelta(hours=5),
                'location':    'Khadakwasla, Pune',
                'hours':       5,
            },
        ]
        created_events = []
        for ed in events_data:
            ev, _ = Event.objects.get_or_create(
                title=ed['title'],
                defaults={**ed, 'created_by': po, 'nss_unit': unit, 'max_volunteers': 50}
            )
            created_events.append(ev)

        # Register volunteers to first (completed) event
        for vol in volunteers:
            EventRegistration.objects.get_or_create(
                event=created_events[0], volunteer=vol,
                defaults={'status': 'attended'}
            )

        self.stdout.write('Creating Community data...')
        NGO.objects.get_or_create(
            name='Helping Hands Foundation',
            defaults={
                'nss_unit':     unit,
                'city':         'Pune',
                'focus_areas':  'Education, Women Empowerment',
                'contact_phone':'9988776655',
                'is_active':    True,
                'added_by':     po,
            }
        )
        Hospital.objects.get_or_create(
            name='Sassoon General Hospital',
            defaults={
                'type':           'government',
                'nss_unit':        unit,
                'address':         'Sassoon Road, Pune',
                'city':            'Pune',
                'has_blood_bank':  True,
                'is_active':       True,
                'added_by':        po,
            }
        )
        village, _ = Village.objects.get_or_create(
            name='Wagholi',
            defaults={
                'district':     'Pune',
                'state':        'Maharashtra',
                'population':   15000,
                'nss_unit':      unit,
                'is_adopted':    True,
                'adoption_date': date(2023, 6, 1),
                'added_by':      po,
            }
        )
        Project.objects.get_or_create(
            title='Digital Literacy for Wagholi',
            defaults={
                'description': 'Teaching basic computer skills to village youth',
                'status':      'active',
                'nss_unit':     unit,
                'village':      village,
                'start_date':   date(2024, 1, 1),
                'created_by':   po,
            }
        )

        self.stdout.write(self.style.SUCCESS(
            '\n✅ Seed data created successfully!\n\n'
            '  Programme Officer → po@nsssetu.in     / Admin@1234\n'
            '  Volunteer (any)   → priya@student.in  / Volunteer@1234\n'
            '\n  NSS Unit: MH-NSS-001 — Pune Engineering College\n'
        ))
