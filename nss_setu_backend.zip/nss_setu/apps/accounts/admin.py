"""NSS SETU - Accounts Admin"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.translation import gettext_lazy as _

from .models import User, NSSUnit, VolunteerProfile, ProgrammeOfficerProfile


@admin.register(NSSUnit)
class NSSUnitAdmin(admin.ModelAdmin):
    list_display  = ['unit_number', 'name', 'college', 'district', 'state']
    search_fields = ['unit_number', 'name', 'college']
    list_filter   = ['state']


class VolunteerProfileInline(admin.StackedInline):
    model  = VolunteerProfile
    extra  = 0
    fields = ['roll_number', 'year_of_study', 'department', 'blood_group', 'emergency_contact']


class POProfileInline(admin.StackedInline):
    model  = ProgrammeOfficerProfile
    extra  = 0
    fields = ['employee_id', 'designation', 'department']


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display   = ['email', 'name', 'role', 'college', 'nss_unit', 'is_email_verified', 'is_active']
    list_filter    = ['role', 'is_active', 'is_email_verified', 'nss_unit']
    search_fields  = ['email', 'name', 'college']
    ordering       = ['-date_joined']
    inlines        = [VolunteerProfileInline, POProfileInline]

    fieldsets = (
        (None,          {'fields': ('email', 'password')}),
        (_('Personal'), {'fields': ('name', 'phone', 'bio', 'address', 'profile_image')}),
        (_('NSS Info'), {'fields': ('role', 'college', 'nss_unit')}),
        (_('Status'),   {'fields': ('is_active', 'is_staff', 'is_superuser', 'is_email_verified')}),
        (_('Dates'),    {'fields': ('date_joined', 'last_login')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields':  ('email', 'name', 'role', 'password1', 'password2'),
        }),
    )
    readonly_fields = ['date_joined', 'last_login']
