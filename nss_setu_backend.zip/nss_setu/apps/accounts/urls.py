"""NSS SETU - Accounts URL Configuration"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from . import views

router = DefaultRouter()
router.register('nss-units', views.NSSUnitViewSet, basename='nss-unit')

urlpatterns = [
    # Auth
    path('login/',                   views.LoginView.as_view(),                name='login'),
    path('token/refresh/',           TokenRefreshView.as_view(),               name='token-refresh'),
    path('logout/',                  views.LogoutView.as_view(),               name='logout'),
    path('register/volunteer/',      views.VolunteerRegisterView.as_view(),    name='register-volunteer'),
    path('register/admin/',          views.AdminRegisterView.as_view(),        name='register-admin'),

    # Profile
    path('me/',                      views.MyProfileView.as_view(),            name='my-profile'),
    path('change-password/',         views.ChangePasswordView.as_view(),       name='change-password'),

    # Email Verification
    path('verify-email/',            views.EmailVerifyView.as_view(),          name='verify-email'),

    # Password Reset
    path('password-reset/',          views.PasswordResetRequestView.as_view(), name='password-reset'),
    path('password-reset/confirm/',  views.PasswordResetConfirmView.as_view(), name='password-reset-confirm'),

    # User Management (Admin)
    path('users/',                   views.UserListView.as_view(),             name='user-list'),
    path('users/<uuid:id>/',         views.UserDetailView.as_view(),           name='user-detail'),

    # NSS Units
    path('', include(router.urls)),
]
