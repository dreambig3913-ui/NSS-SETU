"""
NSS SETU - Accounts Models
Custom User model with role-based access for Volunteers and Programme Officers
"""

import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


class NSSUnit(models.Model):
    """Represents an NSS Unit at a college"""
    name        = models.CharField(max_length=200)
    unit_number = models.CharField(max_length=50, unique=True)
    college     = models.CharField(max_length=300)
    district    = models.CharField(max_length=100, blank=True)
    state       = models.CharField(max_length=100, default='Maharashtra')
    created_at  = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.unit_number} - {self.college}"

    class Meta:
        verbose_name = "NSS Unit"
        verbose_name_plural = "NSS Units"
        ordering = ['unit_number']


class UserManager(BaseUserManager):
    """Custom manager for User model"""

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Email is required')
        email = self.normalize_email(email)
        user  = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('role', User.Role.ADMIN)
        extra_fields.setdefault('is_email_verified', True)
        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """
    Custom User model supporting two roles:
    - VOLUNTEER (Student)
    - ADMIN (Programme Officer)
    """

    class Role(models.TextChoices):
        VOLUNTEER = 'volunteer', _('Volunteer')
        ADMIN     = 'admin',     _('Programme Officer / Admin')

    # ── Core fields ──────────────────────────────────────────────────────────
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email      = models.EmailField(unique=True, db_index=True)
    name       = models.CharField(max_length=200)
    role       = models.CharField(max_length=20, choices=Role.choices, default=Role.VOLUNTEER)
    phone      = models.CharField(max_length=15, blank=True)
    college    = models.CharField(max_length=300, blank=True)
    nss_unit   = models.ForeignKey(
        NSSUnit, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='members'
    )

    # ── Profile ───────────────────────────────────────────────────────────────
    profile_image = models.ImageField(upload_to='profiles/', null=True, blank=True)
    bio           = models.TextField(blank=True)
    address       = models.TextField(blank=True)

    # ── Status & Verification ─────────────────────────────────────────────────
    is_active          = models.BooleanField(default=True)
    is_staff           = models.BooleanField(default=False)
    is_email_verified  = models.BooleanField(default=False)
    email_verify_token = models.CharField(max_length=100, blank=True)
    password_reset_token = models.CharField(max_length=100, blank=True)
    password_reset_expires = models.DateTimeField(null=True, blank=True)

    # ── Timestamps ────────────────────────────────────────────────────────────
    date_joined = models.DateTimeField(default=timezone.now)
    last_login  = models.DateTimeField(null=True, blank=True)

    objects = UserManager()

    USERNAME_FIELD  = 'email'
    REQUIRED_FIELDS = ['name']

    def __str__(self):
        return f"{self.name} ({self.role})"

    @property
    def is_volunteer(self):
        return self.role == self.Role.VOLUNTEER

    @property
    def is_programme_officer(self):
        return self.role == self.Role.ADMIN

    @property
    def total_hours(self):
        return self.service_hours.aggregate(
            total=models.Sum('hours')
        )['total'] or 0

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"
        ordering = ['-date_joined']


class VolunteerProfile(models.Model):
    """Extended profile for Volunteers"""
    user          = models.OneToOneField(User, on_delete=models.CASCADE, related_name='volunteer_profile')
    roll_number   = models.CharField(max_length=50, blank=True)
    year_of_study = models.PositiveSmallIntegerField(null=True, blank=True)
    department    = models.CharField(max_length=200, blank=True)
    blood_group   = models.CharField(max_length=5, blank=True)
    emergency_contact = models.CharField(max_length=15, blank=True)
    joined_nss_on = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"Profile of {self.user.name}"

    class Meta:
        verbose_name = "Volunteer Profile"


class ProgrammeOfficerProfile(models.Model):
    """Extended profile for Programme Officers"""
    user            = models.OneToOneField(User, on_delete=models.CASCADE, related_name='po_profile')
    employee_id     = models.CharField(max_length=50, blank=True)
    designation     = models.CharField(max_length=200, blank=True)
    department      = models.CharField(max_length=200, blank=True)
    appointed_on    = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"PO Profile of {self.user.name}"

    class Meta:
        verbose_name = "Programme Officer Profile"
