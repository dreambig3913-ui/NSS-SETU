"""
NSS SETU - Email Utilities
Sends verification and password reset emails
"""

from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags


def send_verification_email(user):
    """Send email verification link to newly registered user"""
    subject = "Verify your NSS SETU account"
    verify_url = f"{getattr(settings, 'FRONTEND_URL', 'http://localhost:3000')}/verify-email?token={user.email_verify_token}"

    html_message = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px;">
        <div style="background: #1a56db; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
            <h1 style="color: white; margin: 0;">NSS SETU</h1>
            <p style="color: #bcd4ff; margin: 5px 0 0;">National Service Scheme Platform</p>
        </div>
        <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px;">
            <h2 style="color: #1a1a2e;">Hello, {user.name}!</h2>
            <p>Thank you for registering as an NSS Volunteer. Please verify your email address to activate your account.</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{verify_url}"
                   style="background: #1a56db; color: white; padding: 14px 32px;
                          border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 16px;">
                    Verify Email Address
                </a>
            </div>
            <p style="color: #666; font-size: 13px;">
                Or paste this link in your browser:<br>
                <a href="{verify_url}" style="color: #1a56db;">{verify_url}</a>
            </p>
            <p style="color: #999; font-size: 12px; border-top: 1px solid #ddd; padding-top: 15px; margin-top: 20px;">
                If you did not create an account, please ignore this email.
            </p>
        </div>
    </body>
    </html>
    """

    send_mail(
        subject=subject,
        message=strip_tags(html_message),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        html_message=html_message,
        fail_silently=True,
    )


def send_password_reset_email(user):
    """Send password reset link"""
    subject = "Reset your NSS SETU password"
    reset_url = f"{getattr(settings, 'FRONTEND_URL', 'http://localhost:3000')}/reset-password?token={user.password_reset_token}"

    html_message = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px;">
        <div style="background: #1a56db; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
            <h1 style="color: white; margin: 0;">NSS SETU</h1>
        </div>
        <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px;">
            <h2 style="color: #1a1a2e;">Password Reset Request</h2>
            <p>Hello {user.name}, we received a request to reset your password.</p>
            <p>This link will expire in <strong>24 hours</strong>.</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{reset_url}"
                   style="background: #e53e3e; color: white; padding: 14px 32px;
                          border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 16px;">
                    Reset Password
                </a>
            </div>
            <p style="color: #999; font-size: 12px; border-top: 1px solid #ddd; padding-top: 15px; margin-top: 20px;">
                If you did not request a password reset, please ignore this email.
                Your password will remain unchanged.
            </p>
        </div>
    </body>
    </html>
    """

    send_mail(
        subject=subject,
        message=strip_tags(html_message),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        html_message=html_message,
        fail_silently=True,
    )


def send_certificate_issued_email(certificate):
    """Notify volunteer when their certificate is issued"""
    user    = certificate.volunteer
    subject = f"Your NSS Certificate is Ready! — {certificate.certificate_number}"

    html_message = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px;">
        <div style="background: #1a56db; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
            <h1 style="color: white; margin: 0;">🎓 NSS SETU</h1>
        </div>
        <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px;">
            <h2 style="color: #1a1a2e;">Congratulations, {user.name}!</h2>
            <p>
                You have successfully completed <strong>{certificate.total_hours} hours</strong>
                of NSS Community Service. Your certificate has been issued.
            </p>
            <div style="background: white; border: 2px solid #1a56db; border-radius: 8px;
                        padding: 20px; margin: 20px 0; text-align: center;">
                <p style="margin: 0; color: #666; font-size: 13px;">Certificate Number</p>
                <p style="margin: 5px 0; font-size: 22px; font-weight: bold; color: #1a56db; letter-spacing: 1px;">
                    {certificate.certificate_number}
                </p>
                <p style="margin: 0; color: #666; font-size: 13px;">Issued on {certificate.issued_on}</p>
            </div>
            <p>Log in to NSS SETU to download your certificate.</p>
            <p style="color: #999; font-size: 12px; border-top: 1px solid #ddd; padding-top: 15px; margin-top: 20px;">
                Verify certificate at: nsssetu.in/verify/{certificate.verify_token}
            </p>
        </div>
    </body>
    </html>
    """

    send_mail(
        subject=subject,
        message=strip_tags(html_message),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        html_message=html_message,
        fail_silently=True,
    )
