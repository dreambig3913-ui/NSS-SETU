"""
NSS SETU - Accounts Serializers
"""

import uuid
from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import NSSUnit, VolunteerProfile, ProgrammeOfficerProfile

User = get_user_model()


# ─── JWT Custom Token ─────────────────────────────────────────────────────────

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """Adds user info to JWT token claims"""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['name']  = user.name
        token['email'] = user.email
        token['role']  = user.role
        return token

    def validate(self, attrs):
        data = super().validate(attrs)
        data['user'] = {
            'id':    str(self.user.id),
            'name':  self.user.name,
            'email': self.user.email,
            'role':  self.user.role,
            'is_email_verified': self.user.is_email_verified,
        }
        return data


# ─── NSSUnit ─────────────────────────────────────────────────────────────────

class NSSUnitSerializer(serializers.ModelSerializer):
    class Meta:
        model  = NSSUnit
        fields = ['id', 'name', 'unit_number', 'college', 'district', 'state']


# ─── Volunteer Registration ───────────────────────────────────────────────────

class VolunteerRegisterSerializer(serializers.ModelSerializer):
    password         = serializers.CharField(write_only=True, min_length=8)
    confirm_password = serializers.CharField(write_only=True)
    nss_unit_id      = serializers.PrimaryKeyRelatedField(
        queryset=NSSUnit.objects.all(), source='nss_unit', write_only=True, required=False
    )

    class Meta:
        model  = User
        fields = [
            'name', 'email', 'phone', 'college',
            'nss_unit_id', 'password', 'confirm_password'
        ]

    def validate(self, data):
        if data['password'] != data.pop('confirm_password'):
            raise serializers.ValidationError({'confirm_password': 'Passwords do not match.'})
        return data

    def create(self, validated_data):
        password = validated_data.pop('password')
        token    = str(uuid.uuid4())
        user = User.objects.create_user(
            **validated_data,
            password=password,
            role=User.Role.VOLUNTEER,
            email_verify_token=token,
        )
        VolunteerProfile.objects.create(user=user)
        # TODO: send_verification_email(user)
        return user


# ─── Admin / Programme Officer Registration ───────────────────────────────────

class AdminRegisterSerializer(serializers.ModelSerializer):
    password         = serializers.CharField(write_only=True, min_length=8)
    confirm_password = serializers.CharField(write_only=True)
    nss_unit_id      = serializers.PrimaryKeyRelatedField(
        queryset=NSSUnit.objects.all(), source='nss_unit', write_only=True, required=False
    )

    class Meta:
        model  = User
        fields = [
            'name', 'email', 'college',
            'nss_unit_id', 'password', 'confirm_password'
        ]

    def validate(self, data):
        if data['password'] != data.pop('confirm_password'):
            raise serializers.ValidationError({'confirm_password': 'Passwords do not match.'})
        return data

    def create(self, validated_data):
        password = validated_data.pop('password')
        token    = str(uuid.uuid4())
        user = User.objects.create_user(
            **validated_data,
            password=password,
            role=User.Role.ADMIN,
            is_staff=True,
            email_verify_token=token,
        )
        ProgrammeOfficerProfile.objects.create(user=user)
        return user


# ─── User Detail / Profile ────────────────────────────────────────────────────

class VolunteerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model  = VolunteerProfile
        fields = ['roll_number', 'year_of_study', 'department', 'blood_group',
                  'emergency_contact', 'joined_nss_on']


class ProgrammeOfficerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model  = ProgrammeOfficerProfile
        fields = ['employee_id', 'designation', 'department', 'appointed_on']


class UserProfileSerializer(serializers.ModelSerializer):
    nss_unit          = NSSUnitSerializer(read_only=True)
    volunteer_profile = VolunteerProfileSerializer(read_only=True)
    po_profile        = ProgrammeOfficerProfileSerializer(read_only=True)
    total_hours       = serializers.ReadOnlyField()
    profile_image_url = serializers.SerializerMethodField()

    class Meta:
        model  = User
        fields = [
            'id', 'name', 'email', 'phone', 'role', 'college',
            'nss_unit', 'bio', 'address', 'profile_image', 'profile_image_url',
            'is_email_verified', 'date_joined', 'total_hours',
            'volunteer_profile', 'po_profile',
        ]
        read_only_fields = ['id', 'email', 'role', 'date_joined', 'total_hours', 'is_email_verified']

    def get_profile_image_url(self, obj):
        request = self.context.get('request')
        if obj.profile_image and request:
            return request.build_absolute_uri(obj.profile_image.url)
        return None


class UserUpdateSerializer(serializers.ModelSerializer):
    """For profile updates (no email/role change)"""
    nss_unit_id = serializers.PrimaryKeyRelatedField(
        queryset=NSSUnit.objects.all(), source='nss_unit', required=False
    )

    class Meta:
        model  = User
        fields = ['name', 'phone', 'college', 'nss_unit_id', 'bio', 'address', 'profile_image']


# ─── Password ─────────────────────────────────────────────────────────────────

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, min_length=8)
    confirm_new  = serializers.CharField(required=True)

    def validate(self, data):
        if data['new_password'] != data['confirm_new']:
            raise serializers.ValidationError({'confirm_new': 'Passwords do not match.'})
        return data


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    token       = serializers.CharField()
    new_password = serializers.CharField(min_length=8)
    confirm_new  = serializers.CharField()

    def validate(self, data):
        if data['new_password'] != data['confirm_new']:
            raise serializers.ValidationError({'confirm_new': 'Passwords do not match.'})
        return data


# ─── Email Verification ───────────────────────────────────────────────────────

class EmailVerifySerializer(serializers.Serializer):
    token = serializers.CharField()
