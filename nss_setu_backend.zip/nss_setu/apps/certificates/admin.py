"""NSS SETU - Certificates Admin"""
from django.contrib import admin
from .models import Certificate


@admin.register(Certificate)
class CertificateAdmin(admin.ModelAdmin):
    list_display  = ['certificate_number', 'volunteer', 'total_hours', 'issued_on', 'status']
    list_filter   = ['status', 'nss_unit']
    search_fields = ['certificate_number', 'volunteer__name', 'volunteer__email']
    readonly_fields = ['certificate_number', 'verify_token', 'created_at']
