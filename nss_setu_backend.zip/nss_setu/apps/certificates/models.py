"""
NSS SETU - Certificate Models
Auto-generated PDF certificates for volunteers who complete required hours
"""

import uuid
from django.db import models
from django.conf import settings
from django.utils import timezone


class Certificate(models.Model):
    """Certificate issued to a volunteer on completing required NSS service hours"""

    class Status(models.TextChoices):
        PENDING  = 'pending',  'Pending'
        ISSUED   = 'issued',   'Issued'
        REVOKED  = 'revoked',  'Revoked'

    id           = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    volunteer    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='certificates', limit_choices_to={'role': 'volunteer'}
    )
    certificate_number = models.CharField(max_length=50, unique=True, blank=True)
    total_hours  = models.DecimalField(max_digits=6, decimal_places=2)
    issued_on    = models.DateField(default=timezone.now)
    valid_till   = models.DateField(null=True, blank=True)
    issued_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='issued_certificates',
        limit_choices_to={'role': 'admin'}
    )
    nss_unit     = models.ForeignKey(
        'accounts.NSSUnit', on_delete=models.SET_NULL, null=True, blank=True
    )
    status       = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    pdf_file     = models.FileField(upload_to='certificates/', null=True, blank=True)
    verify_token = models.UUIDField(default=uuid.uuid4, unique=True)
    notes        = models.TextField(blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Certificate {self.certificate_number} — {self.volunteer.name}"

    def save(self, *args, **kwargs):
        if not self.certificate_number:
            year = timezone.now().year
            unit = self.nss_unit.unit_number if self.nss_unit else 'NSS'
            count = Certificate.objects.filter(
                issued_on__year=year
            ).count() + 1
            self.certificate_number = f"NSS/{unit}/{year}/{count:04d}"
        super().save(*args, **kwargs)

    class Meta:
        ordering     = ['-issued_on']
        verbose_name = "Certificate"
