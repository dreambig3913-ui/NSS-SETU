"""
NSS SETU - PDF Certificate Generator
Uses ReportLab to generate styled certificates
"""

import os
from io import BytesIO
from datetime import date

from django.conf import settings
from django.core.files import File


def generate_certificate_pdf(certificate) -> bytes:
    """
    Generate a PDF certificate and return bytes.
    Falls back gracefully if reportlab is not installed.
    """
    try:
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib import colors
        from reportlab.lib.units import cm, mm
        from reportlab.pdfgen import canvas
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import Paragraph
        from reportlab.lib.enums import TA_CENTER
    except ImportError:
        # Return a minimal placeholder if ReportLab isn't installed
        return b"%PDF placeholder - install reportlab for real PDFs"

    volunteer = certificate.volunteer
    unit      = volunteer.nss_unit

    buffer = BytesIO()
    page_w, page_h = landscape(A4)
    c = canvas.Canvas(buffer, pagesize=landscape(A4))

    # ── Background ───────────────────────────────────────────────────────────
    c.setFillColorRGB(0.97, 0.97, 1.0)
    c.rect(0, 0, page_w, page_h, fill=True, stroke=False)

    # ── Outer Border ─────────────────────────────────────────────────────────
    c.setStrokeColorRGB(0.1, 0.35, 0.7)
    c.setLineWidth(6)
    c.rect(20, 20, page_w - 40, page_h - 40, fill=False, stroke=True)
    c.setStrokeColorRGB(0.2, 0.55, 0.9)
    c.setLineWidth(2)
    c.rect(30, 30, page_w - 60, page_h - 60, fill=False, stroke=True)

    # ── NSS Logo placeholder circle ───────────────────────────────────────────
    c.setFillColorRGB(0.1, 0.35, 0.7)
    c.circle(page_w / 2, page_h - 80, 30, fill=True, stroke=False)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(page_w / 2, page_h - 86, "NSS")

    # ── Header ────────────────────────────────────────────────────────────────
    c.setFillColorRGB(0.1, 0.35, 0.7)
    c.setFont("Helvetica-Bold", 28)
    c.drawCentredString(page_w / 2, page_h - 130, "NATIONAL SERVICE SCHEME")

    c.setFont("Helvetica", 14)
    c.setFillColorRGB(0.3, 0.3, 0.3)
    college_name = unit.college if unit else volunteer.college or "College"
    c.drawCentredString(page_w / 2, page_h - 155, college_name)

    # ── Certificate Title ─────────────────────────────────────────────────────
    c.setFillColorRGB(0.7, 0.5, 0.0)
    c.setFont("Helvetica-Bold", 36)
    c.drawCentredString(page_w / 2, page_h - 210, "CERTIFICATE OF SERVICE")

    # ── Body Text ─────────────────────────────────────────────────────────────
    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.setFont("Helvetica", 14)
    c.drawCentredString(page_w / 2, page_h - 260, "This is to certify that")

    c.setFillColorRGB(0.1, 0.35, 0.7)
    c.setFont("Helvetica-Bold", 26)
    c.drawCentredString(page_w / 2, page_h - 295, volunteer.name.upper())

    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.setFont("Helvetica", 14)
    c.drawCentredString(
        page_w / 2, page_h - 330,
        f"has successfully completed  {certificate.total_hours}  hours of NSS Community Service"
    )

    unit_str = f"NSS Unit: {unit.unit_number}" if unit else "NSS Programme"
    c.drawCentredString(page_w / 2, page_h - 358, f"under the {unit_str}")

    # ── Date & Certificate Number ─────────────────────────────────────────────
    c.setFont("Helvetica", 11)
    c.setFillColorRGB(0.4, 0.4, 0.4)
    issued = certificate.issued_on.strftime("%d %B %Y") if certificate.issued_on else str(date.today())
    c.drawString(60, 100, f"Date of Issue:  {issued}")
    c.drawString(60, 78,  f"Certificate No: {certificate.certificate_number}")
    c.drawString(60, 56,  f"Verify at:      nsssetu.in/verify/{certificate.verify_token}")

    # ── Signature Block ───────────────────────────────────────────────────────
    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.setFont("Helvetica", 11)
    officer_name = certificate.issued_by.name if certificate.issued_by else "Programme Officer"
    c.line(page_w - 240, 110, page_w - 60, 110)
    c.drawCentredString(page_w - 150, 95,  officer_name)
    c.drawCentredString(page_w - 150, 78,  "Programme Officer")
    c.drawCentredString(page_w - 150, 61,  "NSS")

    c.save()
    buffer.seek(0)
    return buffer.read()


def attach_pdf_to_certificate(certificate):
    """Generate PDF and attach it to the Certificate model instance"""
    pdf_bytes = generate_certificate_pdf(certificate)
    filename  = f"certificate_{certificate.certificate_number.replace('/', '_')}.pdf"
    certificate.pdf_file.save(filename, File(BytesIO(pdf_bytes)), save=True)
