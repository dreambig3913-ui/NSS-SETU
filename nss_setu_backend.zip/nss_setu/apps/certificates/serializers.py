"""NSS SETU - Certificates Serializers"""

from rest_framework import serializers
from .models import Certificate


class CertificateSerializer(serializers.ModelSerializer):
    volunteer_name = serializers.CharField(source='volunteer.name', read_only=True)
    issued_by_name = serializers.CharField(source='issued_by.name', read_only=True)
    nss_unit_name  = serializers.CharField(source='nss_unit.name', read_only=True)
    pdf_url        = serializers.SerializerMethodField()

    class Meta:
        model  = Certificate
        fields = [
            'id', 'certificate_number', 'volunteer', 'volunteer_name',
            'total_hours', 'issued_on', 'valid_till', 'issued_by_name',
            'nss_unit_name', 'status', 'pdf_url', 'verify_token', 'notes', 'created_at',
        ]
        read_only_fields = ['id', 'certificate_number', 'verify_token', 'created_at', 'pdf_url']

    def get_pdf_url(self, obj):
        request = self.context.get('request')
        if obj.pdf_file and request:
            return request.build_absolute_uri(obj.pdf_file.url)
        return None


class CertificateCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Certificate
        fields = ['volunteer', 'total_hours', 'issued_on', 'valid_till', 'nss_unit', 'notes']
