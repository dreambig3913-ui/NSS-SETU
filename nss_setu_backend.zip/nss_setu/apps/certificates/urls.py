"""NSS SETU - Certificates URLs"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register('', views.CertificateViewSet, basename='certificate')

urlpatterns = [
    path('verify/<uuid:token>/', views.VerifyCertificateView.as_view(), name='verify-certificate'),
    path('', include(router.urls)),
]
