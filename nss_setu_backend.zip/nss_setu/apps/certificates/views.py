"""NSS SETU - Certificates Views"""

from django.conf import settings
from django.db.models import Sum
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404

from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from apps.attendance.models import ServiceHours
from apps.accounts.permissions import IsProgrammeOfficer, IsVolunteer
from .models import Certificate
from .serializers import CertificateSerializer, CertificateCreateSerializer
from .utils import attach_pdf_to_certificate

REQUIRED_HOURS = getattr(settings, 'NSS_REQUIRED_HOURS', 120)


class CertificateViewSet(viewsets.ModelViewSet):
    """
    GET    /api/v1/certificates/              → Admin: all; Volunteer: own
    POST   /api/v1/certificates/              → Issue certificate (admin)
    GET    /api/v1/certificates/<id>/         → Detail
    GET    /api/v1/certificates/<id>/download/→ Download PDF
    POST   /api/v1/certificates/generate/    → Auto-generate for eligible volunteers
    """
    queryset = Certificate.objects.select_related('volunteer', 'nss_unit', 'issued_by').all()

    def get_serializer_class(self):
        if self.action == 'create':
            return CertificateCreateSerializer
        return CertificateSerializer

    def get_permissions(self):
        if self.action in ['create', 'generate_all', 'list_all']:
            return [IsProgrammeOfficer()]
        return [IsAuthenticated()]

    def get_queryset(self):
        user = self.request.user
        qs   = super().get_queryset()
        if user.role == 'volunteer':
            qs = qs.filter(volunteer=user)
        return qs

    def perform_create(self, serializer):
        cert = serializer.save(
            issued_by=self.request.user,
            nss_unit=self.request.user.nss_unit,
            status=Certificate.Status.ISSUED,
        )
        attach_pdf_to_certificate(cert)

    @action(detail=True, methods=['get'])
    def download(self, request, pk=None):
        """GET /api/v1/certificates/<id>/download/ — Download PDF"""
        cert = self.get_object()
        if not cert.pdf_file:
            return Response({'error': 'PDF not yet generated.'}, status=404)
        response = FileResponse(
            cert.pdf_file.open('rb'),
            as_attachment=True,
            filename=f"NSS_Certificate_{cert.certificate_number.replace('/', '_')}.pdf"
        )
        return response

    @action(detail=False, methods=['post'], url_path='generate-eligible')
    def generate_all(self, request):
        """
        POST /api/v1/certificates/generate-eligible/
        Auto-generate certificates for all eligible volunteers in the officer's unit
        """
        nss_unit = request.user.nss_unit
        if not nss_unit:
            return Response({'error': 'You are not assigned to an NSS unit.'}, status=400)

        from django.contrib.auth import get_user_model
        User = get_user_model()

        volunteers = User.objects.filter(role='volunteer', nss_unit=nss_unit)
        issued = []
        skipped = []

        for vol in volunteers:
            total = ServiceHours.objects.filter(
                volunteer=vol, verified=True
            ).aggregate(t=Sum('hours'))['t'] or 0

            if total < REQUIRED_HOURS:
                skipped.append({'volunteer': vol.name, 'hours': float(total), 'reason': 'Insufficient hours'})
                continue

            if Certificate.objects.filter(volunteer=vol, status='issued').exists():
                skipped.append({'volunteer': vol.name, 'reason': 'Certificate already issued'})
                continue

            cert = Certificate.objects.create(
                volunteer  = vol,
                total_hours= total,
                issued_by  = request.user,
                nss_unit   = nss_unit,
                status     = Certificate.Status.ISSUED,
            )
            attach_pdf_to_certificate(cert)
            issued.append({'volunteer': vol.name, 'certificate_number': cert.certificate_number})

        return Response({
            'issued':  issued,
            'skipped': skipped,
            'total_issued': len(issued),
        })

    @action(detail=False, methods=['get'], url_path='my-certificate')
    def my_certificate(self, request):
        """GET /api/v1/certificates/my-certificate/ — Volunteer's own certificate"""
        certs = Certificate.objects.filter(volunteer=request.user, status='issued')
        if not certs.exists():
            # Check eligibility
            total = ServiceHours.objects.filter(
                volunteer=request.user, verified=True
            ).aggregate(t=Sum('hours'))['t'] or 0
            return Response({
                'has_certificate': False,
                'total_hours': float(total),
                'required_hours': REQUIRED_HOURS,
                'eligible': float(total) >= REQUIRED_HOURS,
            })
        serializer = CertificateSerializer(certs.first(), context={'request': request})
        return Response({'has_certificate': True, **serializer.data})


class VerifyCertificateView(generics.GenericAPIView):
    """
    GET /api/v1/certificates/verify/<token>/
    Public endpoint to verify certificate authenticity
    """
    permission_classes = [AllowAny]

    def get(self, request, token):
        cert = get_object_or_404(Certificate, verify_token=token, status='issued')
        return Response({
            'valid': True,
            'certificate_number': cert.certificate_number,
            'volunteer_name':     cert.volunteer.name,
            'college':            cert.volunteer.college,
            'total_hours':        str(cert.total_hours),
            'issued_on':          cert.issued_on,
            'nss_unit':           cert.nss_unit.name if cert.nss_unit else None,
        })
