# NSS SETU — Backend

Django + DRF backend for the NSS SETU mobile application.  
Connects NSS Volunteers, Programme Officers, NGOs, Hospitals, and Villages.

---

## 🏗️ Project Structure

```
nss_setu/
├── manage.py
├── requirements.txt
├── .env.example               ← Copy to .env
├── API_DOCS.md                ← Full API reference
│
├── nss_setu/
│   ├── settings.py            ← Main configuration
│   ├── urls.py                ← Root routing
│   ├── wsgi.py
│   └── exceptions.py          ← Custom error handler
│
└── apps/
    ├── accounts/              ← Users, Auth, JWT, NSS Units
    │   ├── models.py          → User, NSSUnit, VolunteerProfile, POProfile
    │   ├── serializers.py
    │   ├── views.py
    │   ├── permissions.py     → IsVolunteer, IsProgrammeOfficer, IsOwnerOrAdmin
    │   ├── email_utils.py     → Verification & reset emails
    │   └── management/
    │       └── commands/
    │           └── seed_data.py
    │
    ├── events/                ← Events & Registrations
    │   ├── models.py          → Event, EventRegistration
    │   ├── serializers.py
    │   └── views.py
    │
    ├── attendance/            ← QR Attendance & Service Hours
    │   ├── models.py          → AttendanceSession, AttendanceRecord, ServiceHours
    │   ├── serializers.py
    │   └── views.py
    │
    ├── certificates/          ← PDF Certificate Generation
    │   ├── models.py          → Certificate
    │   ├── serializers.py
    │   ├── views.py
    │   └── utils.py           → ReportLab PDF generator
    │
    ├── community/             ← NGOs, Hospitals, Villages, Projects
    │   ├── models.py
    │   ├── serializers.py
    │   └── views.py
    │
    └── dashboard/             ← Analytics & Stats APIs
        └── views.py
```

---

## ⚙️ Setup

### 1. Clone & Virtual Environment

```bash
git clone https://github.com/your-org/nss-setu-backend.git
cd nss-setu-backend

python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Environment

```bash
cp .env.example .env
# Edit .env with your values
```

For local development, leave `USE_SQLITE=True` — no PostgreSQL setup needed.

### 4. Run Migrations

```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Create Superuser

```bash
python manage.py createsuperuser
```

### 6. Seed Sample Data (Optional)

```bash
python manage.py seed_data
```

Creates: 1 NSS Unit, 1 Programme Officer, 5 Volunteers, 3 Events, sample NGO/Hospital/Village/Project.

Credentials after seeding:
- Programme Officer: `po@nsssetu.in` / `Admin@1234`
- Volunteer: `priya@student.in` / `Volunteer@1234`

### 7. Run Server

```bash
python manage.py runserver
```

---

## 📚 API & Docs

| URL | Description |
|---|---|
| `http://localhost:8000/docs/` | Swagger UI — interactive API explorer |
| `http://localhost:8000/redoc/` | ReDoc — clean API reference |
| `http://localhost:8000/admin/` | Django Admin panel |
| `API_DOCS.md` | Full API reference with examples |

---

## 🔐 Authentication Flow

```
1. Register  → POST /api/v1/auth/register/volunteer/
2. Login     → POST /api/v1/auth/login/
             ← Returns { access, refresh, user }
3. Use APIs  → Header: Authorization: Bearer <access_token>
4. Refresh   → POST /api/v1/auth/token/refresh/
5. Logout    → POST /api/v1/auth/logout/  { refresh }
```

---

## 👥 Roles & Permissions

| Action | Volunteer | Programme Officer |
|---|:---:|:---:|
| View events | ✅ | ✅ |
| Create/edit events | ❌ | ✅ |
| Join events | ✅ | ❌ |
| Scan QR attendance | ✅ | ❌ |
| Create attendance sessions | ❌ | ✅ |
| View own hours | ✅ | ❌ |
| View all hours (unit) | ❌ | ✅ |
| Issue certificates | ❌ | ✅ |
| Download own certificate | ✅ | ✅ |
| Manage NGOs/Hospitals/Villages | ❌ | ✅ |
| Admin dashboard | ❌ | ✅ |

---

## 📦 Key Dependencies

| Package | Version | Purpose |
|---|---|---|
| Django | 4.2 | Web framework |
| djangorestframework | 3.14 | REST API |
| djangorestframework-simplejwt | 5.3 | JWT auth |
| django-cors-headers | 4.3 | CORS for mobile app |
| django-filter | 23.3 | Filtering & search |
| drf-yasg | 1.21 | Swagger/OpenAPI docs |
| qrcode | 7.4 | QR code generation |
| reportlab | 4.0 | PDF certificate generation |
| Pillow | 10.x | Image handling |
| python-decouple | 3.8 | .env config |

---

## 🌐 API Endpoints Summary

```
/api/v1/auth/
  POST  register/volunteer/       Register volunteer
  POST  register/admin/           Register programme officer
  POST  login/                    Login → JWT tokens
  POST  token/refresh/            Refresh access token
  POST  logout/                   Blacklist refresh token
  GET   me/                       Own profile
  PATCH me/                       Update profile
  POST  change-password/
  POST  verify-email/
  POST  password-reset/
  POST  password-reset/confirm/
  GET   users/                    List users (admin)
  GET   nss-units/                List NSS units

/api/v1/events/
  GET   /                         List events
  POST  /                         Create event (admin)
  GET   <id>/                     Event detail
  PATCH <id>/                     Update (admin)
  POST  <id>/join/                Join (volunteer)
  POST  <id>/leave/               Leave (volunteer)
  GET   <id>/volunteers/          Registrations (admin)
  GET   my-events/                My registrations

/api/v1/attendance/
  POST  sessions/                 Create session (admin)
  GET   sessions/                 List sessions
  POST  sessions/<id>/close/      Close session
  GET   sessions/<id>/records/    Attendance records
  POST  sessions/<id>/manual/     Manual mark (admin)
  POST  scan/                     QR scan (volunteer)
  GET   my-hours/                 My service hours
  GET   my-hours/summary/         Hours summary
  GET   hours/                    All hours (admin)

/api/v1/certificates/
  GET   /                         List certificates
  POST  /                         Issue certificate (admin)
  GET   <id>/download/            Download PDF
  POST  generate-eligible/        Auto-issue (admin)
  GET   my-certificate/           Own certificate
  GET   verify/<token>/           Verify (public)

/api/v1/community/
  CRUD  ngos/
  CRUD  hospitals/
  CRUD  villages/
  CRUD  projects/

/api/v1/dashboard/
  GET   volunteer/                Volunteer stats
  GET   admin/                    Unit-level stats (admin)
  GET   unit-stats/               Unit summary (admin)
```

---

## 🚀 Production Checklist

- [ ] Set `DEBUG=False` in `.env`
- [ ] Set strong `SECRET_KEY`
- [ ] Set `USE_SQLITE=False` and configure PostgreSQL
- [ ] Set `EMAIL_BACKEND` to SMTP
- [ ] Configure `ALLOWED_HOSTS` and `CORS_ALLOWED_ORIGINS`
- [ ] Run `python manage.py collectstatic`
- [ ] Set up media file storage (S3 / local volume)
- [ ] Configure Gunicorn + Nginx
- [ ] Set up SSL certificate
