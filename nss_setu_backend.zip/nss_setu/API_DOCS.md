# NSS SETU — API Reference

Base URL: `http://localhost:8000/api/v1`  
Interactive docs: `http://localhost:8000/docs/`

All protected routes require: `Authorization: Bearer <access_token>`

---

## 🔐 Authentication

### Register — Volunteer
```
POST /auth/register/volunteer/
```
**Request:**
```json
{
  "name": "Priya Mehta",
  "email": "priya@student.in",
  "phone": "9876543210",
  "college": "Pune Engineering College",
  "nss_unit_id": 1,
  "password": "Secret@123",
  "confirm_password": "Secret@123"
}
```
**Response `201`:**
```json
{
  "message": "Volunteer registered successfully. Please verify your email.",
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "Priya Mehta",
    "email": "priya@student.in",
    "role": "volunteer"
  },
  "tokens": {
    "access": "eyJhbGciOiJIUzI1NiIs...",
    "refresh": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

---

### Register — Programme Officer
```
POST /auth/register/admin/
```
**Request:**
```json
{
  "name": "Dr. Ramesh Sharma",
  "email": "po@college.in",
  "college": "Pune Engineering College",
  "nss_unit_id": 1,
  "password": "Admin@1234",
  "confirm_password": "Admin@1234"
}
```

---

### Login
```
POST /auth/login/
```
**Request:**
```json
{
  "email": "priya@student.in",
  "password": "Secret@123"
}
```
**Response `200`:**
```json
{
  "access": "eyJhbGciOiJIUzI1NiIs...",
  "refresh": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "550e8400-...",
    "name": "Priya Mehta",
    "email": "priya@student.in",
    "role": "volunteer",
    "is_email_verified": true
  }
}
```

---

### Refresh Token
```
POST /auth/token/refresh/
Body: { "refresh": "<refresh_token>" }
```

### Logout
```
POST /auth/logout/
Body: { "refresh": "<refresh_token>" }
```

---

### My Profile
```
GET  /auth/me/        → get profile
PATCH /auth/me/       → update profile (partial)
```
**PATCH Request:**
```json
{
  "phone": "9999888877",
  "bio": "Passionate NSS volunteer from Pune"
}
```

---

### Change Password
```
POST /auth/change-password/
```
```json
{
  "old_password": "Secret@123",
  "new_password": "NewSecret@456",
  "confirm_new":  "NewSecret@456"
}
```

---

### Email Verification
```
POST /auth/verify-email/
Body: { "token": "<token_from_email>" }
```

### Password Reset — Request
```
POST /auth/password-reset/
Body: { "email": "priya@student.in" }
```

### Password Reset — Confirm
```
POST /auth/password-reset/confirm/
Body: { "token": "...", "new_password": "...", "confirm_new": "..." }
```

---

## 🏫 NSS Units

```
GET    /auth/nss-units/       → List all units (public)
POST   /auth/nss-units/       → Create unit (admin)
GET    /auth/nss-units/<id>/  → Unit detail
PATCH  /auth/nss-units/<id>/  → Update (admin)
```

---

## 📅 Events

### List Events
```
GET /events/?status=published&category=blood_donation
```
**Response `200`:**
```json
{
  "count": 2,
  "results": [
    {
      "id": "abc123",
      "title": "Blood Donation Camp",
      "category": "blood_donation",
      "status": "published",
      "start_date": "2025-09-15T09:00:00+05:30",
      "end_date":   "2025-09-15T15:00:00+05:30",
      "location": "Sassoon General Hospital, Pune",
      "hours": "6.00",
      "volunteer_count": 12,
      "is_registration_open": true,
      "created_by_name": "Dr. Ramesh Sharma",
      "nss_unit_name": "NSS Unit Alpha"
    }
  ]
}
```

### Create Event (Admin)
```
POST /events/
```
```json
{
  "title": "Village Literacy Drive",
  "description": "Teaching basic reading/writing to children in Wagholi",
  "category": "skill_training",
  "status": "published",
  "start_date": "2025-10-01T08:00:00Z",
  "end_date":   "2025-10-01T14:00:00Z",
  "location": "Wagholi Village School, Pune",
  "hours": 6,
  "max_volunteers": 30
}
```

### Join Event (Volunteer)
```
POST /events/<id>/join/
```
**Response `201`:**
```json
{
  "id": "reg-uuid",
  "event": "abc123",
  "volunteer": "vol-uuid",
  "volunteer_name": "Priya Mehta",
  "event_title": "Village Literacy Drive",
  "status": "registered",
  "registered_at": "2025-08-20T10:30:00Z"
}
```

### Leave Event
```
POST /events/<id>/leave/
```

### My Events (Volunteer)
```
GET /events/my-events/
```

### Event Volunteers (Admin)
```
GET /events/<id>/volunteers/
```

---

## 📋 Attendance

### Create Attendance Session (Admin)
```
POST /attendance/sessions/
```
```json
{
  "event": "<event-uuid>",
  "opens_at": "2025-09-15T08:30:00Z",
  "closes_at": "2025-09-15T16:00:00Z",
  "location_name": "Main Gate, Sassoon Hospital"
}
```
**Response `201`:**
```json
{
  "id": "session-uuid",
  "event": "event-uuid",
  "event_title": "Blood Donation Camp",
  "session_token": "a1b2c3d4-...",
  "qr_code_url": "http://localhost:8000/media/qrcodes/qr_session-uuid.png",
  "status": "open",
  "opens_at": "2025-09-15T08:30:00Z",
  "closes_at": "2025-09-15T16:00:00Z",
  "record_count": 0
}
```

### Scan QR Code (Volunteer)
```
POST /attendance/scan/
```
```json
{
  "session_id": "session-uuid",
  "token": "a1b2c3d4-..."
}
```
**Response `201`:**
```json
{
  "message": "Attendance marked successfully!",
  "event": "Blood Donation Camp",
  "hours": "6.00",
  "record": {
    "id": "rec-uuid",
    "volunteer": "vol-uuid",
    "volunteer_name": "Priya Mehta",
    "marked_at": "2025-09-15T09:45:00Z",
    "is_manual": false
  }
}
```

### Manual Attendance (Admin)
```
POST /attendance/sessions/<id>/manual/
Body: { "volunteer_id": "<uuid>", "notes": "Was present, phone died" }
```

### Close Session (Admin)
```
POST /attendance/sessions/<id>/close/
```

### My Service Hours (Volunteer)
```
GET /attendance/my-hours/
```
**Response:**
```json
[
  {
    "id": "sh-uuid",
    "event_title": "Blood Donation Camp",
    "event_date": "2025-09-15T09:00:00Z",
    "event_category": "blood_donation",
    "hours": "6.00",
    "earned_on": "2025-09-15T09:45:00Z",
    "verified": true
  }
]
```

### Hours Summary (Volunteer)
```
GET /attendance/my-hours/summary/
```
```json
{
  "total_hours": 42.0,
  "required_hours": 120,
  "remaining_hours": 78.0,
  "percentage": 35.0,
  "events_attended": 8,
  "eligible_for_certificate": false
}
```

---

## 📜 Certificates

### My Certificate (Volunteer)
```
GET /certificates/my-certificate/
```
```json
{
  "has_certificate": true,
  "id": "cert-uuid",
  "certificate_number": "NSS/MH-001/2025/0001",
  "volunteer_name": "Priya Mehta",
  "total_hours": "125.00",
  "issued_on": "2025-12-01",
  "status": "issued",
  "pdf_url": "http://localhost:8000/media/certificates/NSS_MH-001_2025_0001.pdf"
}
```

### Download Certificate PDF
```
GET /certificates/<id>/download/
→ Returns binary PDF file
```

### Auto-generate for all eligible (Admin)
```
POST /certificates/generate-eligible/
```
```json
{
  "issued": [
    { "volunteer": "Priya Mehta", "certificate_number": "NSS/MH-001/2025/0001" },
    { "volunteer": "Arjun Patil", "certificate_number": "NSS/MH-001/2025/0002" }
  ],
  "skipped": [
    { "volunteer": "Sneha Kulkarni", "hours": 85.0, "reason": "Insufficient hours" }
  ],
  "total_issued": 2
}
```

### Verify Certificate (Public — no auth needed)
```
GET /certificates/verify/<token>/
```
```json
{
  "valid": true,
  "certificate_number": "NSS/MH-001/2025/0001",
  "volunteer_name": "Priya Mehta",
  "college": "Pune Engineering College",
  "total_hours": "125.00",
  "issued_on": "2025-12-01",
  "nss_unit": "NSS Unit Alpha"
}
```

---

## 🗺️ Community

### NGOs
```
GET    /community/ngos/           → List
POST   /community/ngos/           → Create (admin)
GET    /community/ngos/<id>/      → Detail
PATCH  /community/ngos/<id>/      → Update (admin)
DELETE /community/ngos/<id>/      → Delete (admin)
```

### Hospitals
```
GET  /community/hospitals/?has_blood_bank=true
POST /community/hospitals/
```

### Villages
```
GET  /community/villages/?is_adopted=true&district=Pune
POST /community/villages/
```

### Projects
```
GET  /community/projects/?status=active
POST /community/projects/
```
**Create Project:**
```json
{
  "title": "Digital Literacy Camp",
  "description": "Teaching basics to village youth",
  "status": "active",
  "village": "<village-uuid>",
  "ngo_partner": "<ngo-uuid>",
  "start_date": "2025-09-01",
  "budget": 15000.00
}
```

---

## 📊 Dashboard

### Volunteer Dashboard
```
GET /dashboard/volunteer/
```
```json
{
  "volunteer": {
    "name": "Priya Mehta",
    "college": "Pune Engineering College",
    "unit": "NSS Unit Alpha"
  },
  "hours": {
    "total": 42.0,
    "required": 120,
    "remaining": 78.0,
    "percentage": 35.0
  },
  "events": {
    "total_joined": 8,
    "attended": 7,
    "upcoming_count": 1,
    "upcoming": [
      {
        "id": "...",
        "title": "Tree Plantation Drive",
        "start_date": "2025-09-22T08:00:00Z",
        "location": "Khadakwasla, Pune",
        "hours": "5.00"
      }
    ]
  },
  "certificate": {
    "issued": false,
    "eligible": false
  },
  "recent_hours": [
    { "event": "Blood Donation Camp", "hours": "6.00", "date": "2025-09-15T..." }
  ]
}
```

### Admin Dashboard
```
GET /dashboard/admin/
```
```json
{
  "unit": "NSS Unit Alpha",
  "summary": {
    "total_volunteers": 45,
    "total_events": 12,
    "completed_events": 8,
    "total_hours_served": 1240.0,
    "certificates_issued": 5,
    "eligible_no_cert": 3
  },
  "top_volunteers": [
    { "name": "Priya Mehta", "email": "priya@student.in", "hours": 125.0 }
  ],
  "community": {
    "ngos": 3,
    "hospitals": 2,
    "villages": 4,
    "projects": 6
  },
  "monthly_hours_trend": [
    { "month": "Apr 2025", "hours": 180.0 },
    { "month": "May 2025", "hours": 240.0 }
  ],
  "events_by_category": [
    { "category": "community_service", "count": 4 },
    { "category": "blood_donation", "count": 3 }
  ]
}
```

---

## ⚠️ Error Format

All errors follow a consistent envelope:
```json
{
  "success": false,
  "error": {
    "code": "validation_error",
    "message": "email: This field is required.",
    "details": {
      "email": ["This field is required."]
    }
  }
}
```

| Code | HTTP | Description |
|---|---|---|
| `validation_error` | 400 | Invalid input |
| `authentication_required` | 401 | Missing/expired token |
| `permission_denied` | 403 | Wrong role |
| `not_found` | 404 | Resource not found |
| `too_many_requests` | 429 | Rate limit hit |
| `server_error` | 500 | Unexpected server error |
